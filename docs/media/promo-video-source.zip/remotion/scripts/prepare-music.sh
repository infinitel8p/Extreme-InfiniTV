#!/usr/bin/env bash
# Masters the music bed: +1.7 dB gain, then a lookahead limiter with a -1 dBTP ceiling.
set -euo pipefail
here="$(cd "$(dirname "$0")" && pwd)"
source_file="$here/../../audio/candidate-1.mp3"
target_file="$here/../public/audio/music.wav"
ffmpeg -y -v error -i "$source_file" \
  -af "volume=1.7dB,alimiter=limit=0.891:attack=5:release=80:level=false" \
  -c:a pcm_s24le "$target_file"
ffmpeg -hide_banner -i "$target_file" -af ebur128=peak=true -f null - 2>&1 | tail -14 | grep -E "I:|Peak:"
