import React from "react";
import { AbsoluteFill, Sequence, useCurrentFrame } from "remotion";
import { ColdOpen } from "./beats/ColdOpen";
import { Couch } from "./beats/Couch";
import { Hub } from "./beats/Hub";
import { landscapeLayout, squareLayout } from "./beats/layout";
import { LiveTv } from "./beats/LiveTv";
import { Pocket } from "./beats/Pocket";
import { Search } from "./beats/Search";
import { SlateBackground } from "./components/Background";
import { EndCard } from "./components/EndCard";
import { Fonts } from "./components/Fonts";
import { eased } from "./motion";
import { Soundtrack } from "./Soundtrack";
import { secondsToFrames } from "./theme";
import { beats, CROSSFADE_FRAMES, TOTAL_FRAMES } from "./timeline";

const FADE_TO_BLACK_FRAMES = secondsToFrames(0.6);

const beatSpan = (beat: { from: number; to: number }, extraFrames = 0) => ({
  from: beat.from,
  durationInFrames: beat.to - beat.from + extraFrames,
});

export type PromoFormat = "landscape" | "square";

export const Promo: React.FC<{ format: PromoFormat }> = ({ format }) => {
  const frame = useCurrentFrame();
  const isSquare = format === "square";
  const layout = isSquare ? squareLayout : landscapeLayout;
  const endCardOpacity = eased(frame, beats.endCard.from, CROSSFADE_FRAMES);
  const blackout = eased(frame, TOTAL_FRAMES - FADE_TO_BLACK_FRAMES, FADE_TO_BLACK_FRAMES);

  return (
    <AbsoluteFill style={{ background: "#0b0d12" }}>
      <Fonts />
      <SlateBackground />
      <Sequence {...beatSpan(beats.coldOpen)} name="Cold open">
        <ColdOpen />
      </Sequence>
      <Sequence {...beatSpan(beats.hub)} name="Beat 1 hub">
        <Hub layout={layout} />
      </Sequence>
      <Sequence {...beatSpan(beats.liveTv)} name="Beat 2 live tv">
        <LiveTv layout={layout} />
      </Sequence>
      <Sequence {...beatSpan(beats.couch)} name="Beat 3 couch">
        <Couch layout={layout} />
      </Sequence>
      <Sequence {...beatSpan(beats.search)} name="Beat 4 search">
        <Search layout={layout} />
      </Sequence>
      <Sequence {...beatSpan(beats.pocket, CROSSFADE_FRAMES)} name="Beat 5 pocket">
        {isSquare ? (
          <Pocket phoneHeight={560} phoneGap={40} groupCenterX={540} groupCenterY={610} captionAlign="above-frame" />
        ) : (
          <Pocket phoneHeight={690} phoneGap={56} groupCenterX={700} groupCenterY={540} captionAlign="right-third" />
        )}
      </Sequence>
      <Sequence {...beatSpan(beats.endCard)} name="Beat 6 end card">
        <AbsoluteFill style={{ opacity: endCardOpacity }}>
          <SlateBackground />
          <EndCard compact={isSquare} />
        </AbsoluteFill>
      </Sequence>
      <AbsoluteFill style={{ background: "#000", opacity: blackout, pointerEvents: "none" }} />
      <Soundtrack />
    </AbsoluteFill>
  );
};
