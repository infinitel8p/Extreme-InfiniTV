import { Easing } from "remotion";

export const colors = {
  background: "#0b0d12",
  surface: "#14171f",
  surfaceRaised: "#1a1e28",
  muted: "#9aa3b2",
  text: "#f4f6fa",
  accent: "oklch(0.78 0.15 330)",
  border: "rgba(255,255,255,0.08)",
  borderStrong: "rgba(255,255,255,0.10)",
};

export const fontFamily = '"Geist Variable", "Inter", system-ui, sans-serif';

export const signatureEasing = Easing.bezier(0.16, 1, 0.3, 1);

export const FPS = 30;

export const secondsToFrames = (seconds: number): number => Math.round(seconds * FPS);

export const millisToFrames = (millis: number): number => Math.round((millis / 1000) * FPS);
