import React, { useEffect, useState } from "react";
import { continueRender, delayRender, staticFile } from "remotion";

const fontFaceCss = `
@font-face {
  font-family: "Geist Variable";
  font-style: normal;
  font-display: block;
  font-weight: 100 900;
  src: url(${staticFile("fonts/geist-latin-ext-wght-normal.woff2")}) format("woff2-variations");
  unicode-range: U+0100-02BA,U+02BD-02C5,U+02C7-02CC,U+02CE-02D7,U+02DD-02FF,U+0304,U+0308,U+0329,U+1D00-1DBF,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20C0,U+2113,U+2C60-2C7F,U+A720-A7FF;
}
@font-face {
  font-family: "Geist Variable";
  font-style: normal;
  font-display: block;
  font-weight: 100 900;
  src: url(${staticFile("fonts/geist-latin-wght-normal.woff2")}) format("woff2-variations");
  unicode-range: U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD;
}
`;

const fontLoadSpecs = ['400 16px "Geist Variable"', '500 16px "Geist Variable"', '600 16px "Geist Variable"'];

export const Fonts: React.FC = () => {
  const [handle] = useState(() => delayRender("Loading Geist Variable"));

  useEffect(() => {
    let cancelled = false;
    Promise.all(fontLoadSpecs.map((spec) => document.fonts.load(spec)))
      .then(() => document.fonts.ready)
      .then(() => {
        if (!cancelled) continueRender(handle);
      })
      .catch((error) => {
        console.error("Font load failed", error);
        if (!cancelled) continueRender(handle);
      });
    return () => {
      cancelled = true;
    };
  }, [handle]);

  return <style dangerouslySetInnerHTML={{ __html: fontFaceCss }} />;
};
