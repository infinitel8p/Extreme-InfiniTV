import React from "react";
import { AbsoluteFill } from "remotion";
import { colors } from "../theme";

export const SlateBackground: React.FC = () => {
  return (
    <AbsoluteFill
      style={{
        background: `radial-gradient(ellipse 70% 60% at 50% 45%, #10131b 0%, ${colors.background} 100%)`,
      }}
    />
  );
};
