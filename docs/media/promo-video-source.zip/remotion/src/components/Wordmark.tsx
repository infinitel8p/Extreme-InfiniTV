import React from "react";
import { colors, fontFamily } from "../theme";

export const Wordmark: React.FC<{ fontSize: number }> = ({ fontSize }) => {
  return (
    <div
      style={{
        fontFamily,
        fontSize,
        fontWeight: 600,
        letterSpacing: "-0.02em",
        lineHeight: 1.1,
        color: colors.text,
        whiteSpace: "nowrap",
      }}
    >
      Extreme Infini<span style={{ color: colors.accent }}>TV</span>
    </div>
  );
};
