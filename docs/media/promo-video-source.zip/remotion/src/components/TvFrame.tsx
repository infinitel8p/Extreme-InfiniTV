import React from "react";

type TvFrameProps = {
  width: number;
  top: number;
  aspectRatio?: number;
  children: React.ReactNode;
};

const BEZEL = 10;
const OUTER_RADIUS = 8;

export const TvFrame: React.FC<TvFrameProps> = ({ width, top, aspectRatio = 16 / 9, children }) => {
  const screenWidth = width - BEZEL * 2;
  const screenHeight = Math.round(screenWidth / aspectRatio);
  const height = screenHeight + BEZEL * 2;
  return (
    <div
      style={{
        position: "absolute",
        left: "50%",
        top,
        width,
        height,
        marginLeft: -width / 2,
        borderRadius: OUTER_RADIUS,
        background: "#06070a",
        boxShadow: "0 48px 140px rgba(0,0,0,0.6), 0 10px 30px rgba(0,0,0,0.4)",
      }}
    >
      <div
        style={{
          position: "absolute",
          left: BEZEL,
          top: BEZEL,
          width: screenWidth,
          height: screenHeight,
          borderRadius: 2,
          overflow: "hidden",
          background: "#000",
        }}
      >
        {children}
      </div>
      <div
        style={{
          position: "absolute",
          inset: 0,
          borderRadius: OUTER_RADIUS,
          border: "1px solid rgba(255,255,255,0.08)",
          pointerEvents: "none",
        }}
      />
    </div>
  );
};
