import React from "react";
import { colors, fontFamily } from "../theme";
import { IconName, TablerIcon } from "./icons";

type PillProps = {
  icon?: IconName;
  label: string;
  size?: "regular" | "small";
  opacity?: number;
  offsetY?: number;
};

export const Pill: React.FC<PillProps> = ({ icon, label, size = "regular", opacity = 1, offsetY = 0 }) => {
  const isSmall = size === "small";
  return (
    <div
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: isSmall ? 8 : 12,
        padding: isSmall ? "8px 16px" : "13px 24px 13px 20px",
        borderRadius: 999,
        border: `1px solid ${colors.borderStrong}`,
        background: isSmall ? "rgba(20,23,31,0.7)" : colors.surface,
        color: isSmall ? colors.muted : colors.text,
        fontFamily,
        fontSize: isSmall ? 17 : 23,
        fontWeight: 500,
        letterSpacing: "-0.01em",
        lineHeight: 1.2,
        whiteSpace: "nowrap",
        opacity,
        transform: `translateY(${offsetY}px)`,
      }}
    >
      {icon ? <TablerIcon name={icon} size={isSmall ? 16 : 24} color="rgba(244,246,250,0.92)" /> : null}
      <span>{label}</span>
    </div>
  );
};
