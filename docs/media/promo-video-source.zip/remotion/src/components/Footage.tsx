import React from "react";
import { OffthreadVideo, staticFile } from "remotion";

type FootageProps = {
  clip: string;
  startFrom: number;
  style?: React.CSSProperties;
};

export const Footage: React.FC<FootageProps> = ({ clip, startFrom, style }) => {
  return (
    <OffthreadVideo
      src={staticFile(`footage/${clip}.mp4`)}
      trimBefore={startFrom}
      muted
      pauseWhenBuffering={false}
      style={{ width: "100%", height: "100%", display: "block", objectFit: "cover", ...style }}
    />
  );
};
