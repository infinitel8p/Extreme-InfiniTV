import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { colors, fontFamily, millisToFrames, signatureEasing } from "../theme";
import { IconName, LogoMark } from "./icons";
import { Pill } from "./Pill";
import { Wordmark } from "./Wordmark";

const platforms: { icon: IconName; label: string }[] = [
  { icon: "windows", label: "Windows" },
  { icon: "android", label: "Android" },
  { icon: "tv", label: "Android TV" },
  { icon: "apple", label: "macOS" },
  { icon: "linux", label: "Linux" },
  { icon: "web", label: "Web" },
];

const stores = ["Microsoft Store", "Google Play", "Snap Store"];

const ENTER_FRAMES = millisToFrames(640);
const PILL_STAGGER = millisToFrames(60);

const enterAt = (frame: number, start: number) => {
  const progress = interpolate(frame, [start, start + ENTER_FRAMES], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
    easing: signatureEasing,
  });
  return { opacity: progress, offsetY: (1 - progress) * 16, progress };
};

type EndCardProps = {
  compact?: boolean;
};

export const EndCard: React.FC<EndCardProps> = ({ compact = false }) => {
  const frame = useCurrentFrame();
  const logo = enterAt(frame, 0);
  const wordmark = enterAt(frame, 6);
  const pillsStart = 16;
  const quietLine = enterAt(frame, pillsStart + PILL_STAGGER * platforms.length + 6);
  const badges = enterAt(frame, pillsStart + PILL_STAGGER * platforms.length + 14);
  const logoScale = 0.9 + logo.progress * 0.1;
  const logoWidth = compact ? 176 : 208;

  return (
    <AbsoluteFill style={{ alignItems: "center", justifyContent: "center", fontFamily }}>
      <div style={{ display: "flex", flexDirection: "column", alignItems: "center", transform: compact ? "translateY(-10px)" : undefined }}>
        <div style={{ opacity: logo.opacity, transform: `scale(${logoScale})`, transformOrigin: "50% 50%" }}>
          <LogoMark width={logoWidth} />
        </div>
        <div style={{ marginTop: compact ? 26 : 30, opacity: wordmark.opacity, transform: `translateY(${wordmark.offsetY}px)` }}>
          <Wordmark fontSize={compact ? 44 : 50} />
        </div>
        <div
          style={{
            display: "flex",
            flexWrap: compact ? "wrap" : "nowrap",
            justifyContent: "center",
            gap: 14,
            marginTop: compact ? 44 : 56,
            maxWidth: compact ? 760 : undefined,
          }}
        >
          {platforms.map((platform, index) => {
            const enter = enterAt(frame, pillsStart + index * PILL_STAGGER);
            return (
              <Pill key={platform.label} icon={platform.icon} label={platform.label} opacity={enter.opacity} offsetY={enter.offsetY} />
            );
          })}
        </div>
        <div
          style={{
            marginTop: compact ? 40 : 52,
            fontSize: 20,
            fontWeight: 450,
            letterSpacing: "-0.005em",
            color: colors.text,
            opacity: 0.4 * quietLine.opacity,
            transform: `translateY(${quietLine.offsetY}px)`,
            whiteSpace: "nowrap",
          }}
        >
          Open source. GPL-3.0. github.com/infinitel8p/Extreme-InfiniTV
        </div>
        <div
          style={{
            display: "flex",
            gap: 10,
            marginTop: compact ? 24 : 28,
            opacity: badges.opacity,
            transform: `translateY(${badges.offsetY}px)`,
          }}
        >
          {stores.map((store) => (
            <Pill key={store} label={store} size="small" />
          ))}
        </div>
      </div>
    </AbsoluteFill>
  );
};
