import React from "react";

export type IconName = "windows" | "android" | "tv" | "apple" | "linux" | "web";

const iconPaths: Record<IconName, string[]> = {
  windows: [
    "M17.8 20l-12 -1.5c-1 -.1 -1.8 -.9 -1.8 -1.9v-9.2c0 -1 .8 -1.8 1.8 -1.9l12 -1.5c1.2 -.1 2.2 .8 2.2 1.9v12.1c0 1.2 -1.1 2.1 -2.2 1.9l0 .1",
    "M12 5l0 14",
    "M4 12l16 0",
  ],
  android: [
    "M4 10l0 6",
    "M20 10l0 6",
    "M7 9h10v8a1 1 0 0 1 -1 1h-8a1 1 0 0 1 -1 -1v-8a5 5 0 0 1 10 0",
    "M8 3l1 2",
    "M16 3l-1 2",
    "M9 18l0 3",
    "M15 18l0 3",
  ],
  tv: ["M3 9a2 2 0 0 1 2 -2h14a2 2 0 0 1 2 2v9a2 2 0 0 1 -2 2h-14a2 2 0 0 1 -2 -2l0 -9", "M16 3l-4 4l-4 -4"],
  apple: [
    "M8.286 7.008c-3.216 0 -4.286 3.23 -4.286 5.92c0 3.229 2.143 8.072 4.286 8.072c1.165 -.05 1.799 -.538 3.214 -.538c1.406 0 1.607 .538 3.214 .538s4.286 -3.229 4.286 -5.381c-.03 -.011 -2.649 -.434 -2.679 -3.23c-.02 -2.335 2.589 -3.179 2.679 -3.228c-1.096 -1.606 -3.162 -2.113 -3.75 -2.153c-1.535 -.12 -3.032 1.077 -3.75 1.077c-.729 0 -2.036 -1.077 -3.214 -1.077",
    "M12 4a2 2 0 0 0 2 -2a2 2 0 0 0 -2 2",
  ],
  linux: [
    "M10 5a2 2 0 1 0 4 0a2 2 0 1 0 -4 0",
    "M17.723 7.41a7.992 7.992 0 0 0 -3.74 -2.162m-3.971 0a7.993 7.993 0 0 0 -3.789 2.216m-1.881 3.215a8 8 0 0 0 -.342 2.32c0 .738 .1 1.453 .287 2.132m1.96 3.428a7.993 7.993 0 0 0 3.759 2.19m4 0a7.993 7.993 0 0 0 3.747 -2.186m1.962 -3.43a8.008 8.008 0 0 0 .287 -2.131c0 -.764 -.107 -1.503 -.307 -2.203",
    "M3 17a2 2 0 1 0 4 0a2 2 0 1 0 -4 0",
    "M17 17a2 2 0 1 0 4 0a2 2 0 1 0 -4 0",
  ],
  web: ["M3 12a9 9 0 1 0 18 0a9 9 0 0 0 -18 0", "M3.6 9h16.8", "M3.6 15h16.8", "M11.5 3a17 17 0 0 0 0 18", "M12.5 3a17 17 0 0 1 0 18"],
};

type TablerIconProps = {
  name: IconName;
  size?: number;
  color?: string;
  strokeWidth?: number;
};

export const TablerIcon: React.FC<TablerIconProps> = ({ name, size = 22, color = "currentColor", strokeWidth = 1.75 }) => {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke={color}
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
      style={{ display: "block", flexShrink: 0 }}
    >
      {iconPaths[name].map((path) => (
        <path key={path} d={path} />
      ))}
    </svg>
  );
};

export const LogoMark: React.FC<{ width: number }> = ({ width }) => {
  const height = (width * 124) / 224;
  const markColor = "#ec92e5";
  return (
    <svg width={width} height={height} viewBox="8 58 224 124" style={{ display: "block" }}>
      <path d="M65.6 70.2 A50 50 0 1 1 20.2 115.6" fill="none" stroke={markColor} strokeWidth={20} strokeLinecap="round" />
      <circle cx="34.6" cy="84.6" r="9" fill={markColor} />
      <circle cx="170" cy="120" r="50" fill="none" stroke={markColor} strokeWidth={20} />
      <rect x="146.5" y="94" width="13" height="52" rx="6.5" fill={markColor} />
      <rect x="164.5" y="102" width="13" height="36" rx="6.5" fill={markColor} />
      <rect x="182.5" y="110" width="13" height="20" rx="6.5" fill={markColor} />
    </svg>
  );
};
