import React from "react";
import { colors } from "../theme";

type WindowFrameProps = {
  width: number;
  aspectRatio?: number;
  opacity?: number;
  scale?: number;
  offsetY?: number;
  top?: number;
  children: React.ReactNode;
};

export const WindowFrame: React.FC<WindowFrameProps> = ({
  width,
  aspectRatio = 16 / 9,
  opacity = 1,
  scale = 1,
  offsetY = 0,
  top,
  children,
}) => {
  const height = Math.round(width / aspectRatio);
  return (
    <div
      style={{
        position: "absolute",
        left: "50%",
        top: top === undefined ? "50%" : top,
        width,
        height,
        marginLeft: -width / 2,
        marginTop: top === undefined ? -height / 2 : 0,
        opacity,
        transform: `translateY(${offsetY}px) scale(${scale})`,
        transformOrigin: "50% 50%",
        borderRadius: 12,
        boxShadow: "0 40px 120px rgba(0,0,0,0.55), 0 8px 24px rgba(0,0,0,0.35)",
      }}
    >
      <div
        style={{
          position: "absolute",
          inset: 0,
          borderRadius: 12,
          overflow: "hidden",
          background: colors.surface,
        }}
      >
        {children}
      </div>
      <div
        style={{
          position: "absolute",
          inset: 0,
          borderRadius: 12,
          border: `1px solid ${colors.border}`,
          pointerEvents: "none",
        }}
      />
    </div>
  );
};
