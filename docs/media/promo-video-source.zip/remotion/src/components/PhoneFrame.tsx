import React from "react";
import { colors } from "../theme";

type PhoneFrameProps = {
  height: number;
  screenAspect: number;
  opacity?: number;
  offsetY?: number;
  children: React.ReactNode;
};

export const PhoneFrame: React.FC<PhoneFrameProps> = ({ height, screenAspect, opacity = 1, offsetY = 0, children }) => {
  const bezel = Math.round(height * 0.018);
  const screenHeight = height - bezel * 2;
  const screenWidth = Math.round(screenHeight * screenAspect);
  const width = screenWidth + bezel * 2;
  const outerRadius = 44;
  const innerRadius = outerRadius - bezel;
  return (
    <div
      style={{
        position: "relative",
        width,
        height,
        opacity,
        transform: `translateY(${offsetY}px)`,
        borderRadius: outerRadius,
        background: "#0f1117",
        boxShadow: "0 30px 90px rgba(0,0,0,0.55), 0 6px 18px rgba(0,0,0,0.35)",
      }}
    >
      <div
        style={{
          position: "absolute",
          left: bezel,
          top: bezel,
          width: screenWidth,
          height: screenHeight,
          borderRadius: innerRadius,
          overflow: "hidden",
          background: colors.surface,
        }}
      >
        {children}
      </div>
      <div
        style={{
          position: "absolute",
          inset: 0,
          borderRadius: outerRadius,
          border: `2px solid ${colors.borderStrong}`,
          pointerEvents: "none",
        }}
      />
    </div>
  );
};
