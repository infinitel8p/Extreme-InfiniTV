import React from "react";
import { interpolate, useCurrentFrame } from "remotion";
import { colors, fontFamily, millisToFrames, signatureEasing } from "../theme";

export type CaptionAlign = "bottom-left" | "top-left" | "right-third" | "above-frame";

type CaptionProps = {
  eyebrow?: string;
  headline: string;
  sub?: string;
  align: CaptionAlign;
  enterFrame: number;
  exitFrame: number;
  scale?: number;
};

const ENTER_FRAMES = millisToFrames(600);
const EXIT_FRAMES = millisToFrames(400);
const SUB_STAGGER = 4;

const riseAt = (frame: number, enterFrame: number, exitFrame: number, stagger: number) => {
  const enterProgress = interpolate(frame, [enterFrame + stagger, enterFrame + stagger + ENTER_FRAMES], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
    easing: signatureEasing,
  });
  const exitProgress = interpolate(frame, [exitFrame, exitFrame + EXIT_FRAMES], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
    easing: signatureEasing,
  });
  const opacity = enterProgress * (1 - exitProgress);
  const translateY = (1 - enterProgress) * 14 - exitProgress * 12;
  return { opacity, translateY };
};

const positionFor = (align: CaptionAlign): React.CSSProperties => {
  switch (align) {
    case "bottom-left":
      return { left: 96, bottom: 52, maxWidth: 900 };
    case "top-left":
      return { left: 212, top: 104, maxWidth: 900 };
    case "right-third":
      return { left: 1210, top: 0, height: "100%", display: "flex", flexDirection: "column", justifyContent: "center", maxWidth: 620 };
    case "above-frame":
      return { left: 48, top: 176, maxWidth: 984 };
  }
};

export const Caption: React.FC<CaptionProps> = ({ eyebrow, headline, sub, align, enterFrame, exitFrame, scale = 1 }) => {
  const frame = useCurrentFrame();
  const head = riseAt(frame, enterFrame, exitFrame, 0);
  const body = riseAt(frame, enterFrame, exitFrame, SUB_STAGGER);

  if (frame < enterFrame || frame > exitFrame + EXIT_FRAMES) return null;

  return (
    <>
      <div
        style={{
          position: "absolute",
          fontFamily,
          color: colors.text,
          ...positionFor(align),
        }}
      >
        <div style={{ transform: `translateY(${head.translateY}px) scale(${scale})`, transformOrigin: "0 100%", opacity: head.opacity }}>
          {eyebrow ? (
            <div
              style={{
                fontSize: 15,
                fontWeight: 500,
                letterSpacing: "0.18em",
                textTransform: "uppercase",
                color: colors.accent,
                marginBottom: 12,
                lineHeight: 1.2,
              }}
            >
              {eyebrow}
            </div>
          ) : null}
          <div style={{ fontSize: 48, fontWeight: 600, letterSpacing: "-0.02em", lineHeight: 1.1 }}>{headline}</div>
        </div>
        {sub ? (
          <div
            style={{
              transform: `translateY(${body.translateY}px) scale(${scale})`,
              transformOrigin: "0 0",
              opacity: body.opacity,
              marginTop: 10,
              fontSize: 26,
              fontWeight: 450,
              letterSpacing: "-0.005em",
              lineHeight: 1.3,
              color: colors.muted,
            }}
          >
            {sub}
          </div>
        ) : null}
      </div>
    </>
  );
};
