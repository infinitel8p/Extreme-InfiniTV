import React from "react";
import { AbsoluteFill, Sequence, useCurrentFrame } from "remotion";
import { Caption } from "../components/Caption";
import { Footage } from "../components/Footage";
import { WindowFrame } from "../components/WindowFrame";
import { eased, linear } from "../motion";
import { beats, captions, clipInPoints, CROSSFADE_FRAMES, innerCuts } from "../timeline";
import { DesktopLayout } from "./layout";

export const LiveTv: React.FC<{ layout: DesktopLayout }> = ({ layout }) => {
  const frame = useCurrentFrame();
  const duration = beats.liveTv.to - beats.liveTv.from;
  const epgStart = innerCuts.liveTvToEpg - beats.liveTv.from;
  const epgOpacity = eased(frame, epgStart, CROSSFADE_FRAMES);
  const drift = -8 * linear(frame, 0, duration);
  return (
    <AbsoluteFill>
      <WindowFrame width={layout.liveWidth} top={layout.liveTop} offsetY={drift}>
        <Sequence from={0} durationInFrames={epgStart + CROSSFADE_FRAMES} layout="none">
          <Footage clip="livetv" startFrom={clipInPoints.livetv} />
        </Sequence>
        <Sequence from={epgStart} layout="none">
          <AbsoluteFill style={{ opacity: epgOpacity }}>
            <Footage clip="epg" startFrom={clipInPoints.epg} />
          </AbsoluteFill>
        </Sequence>
      </WindowFrame>
      <Caption
        headline="Live TV with a real guide."
        sub="EPG, now and next, catch-up replay."
        align={layout.captionAlign}
        enterFrame={captions.liveTv.enter - beats.liveTv.from}
        exitFrame={captions.liveTv.exit - beats.liveTv.from}
      />
    </AbsoluteFill>
  );
};
