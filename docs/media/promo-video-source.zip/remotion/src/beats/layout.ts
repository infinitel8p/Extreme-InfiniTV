import { CaptionAlign } from "../components/Caption";

export type DesktopLayout = {
  hubWidth: number;
  hubTop: number;
  liveWidth: number;
  liveTop: number;
  searchWidth: number;
  searchTop: number;
  tvWidth: number;
  tvTop: number;
  captionAlign: CaptionAlign;
};

export const landscapeLayout: DesktopLayout = {
  hubWidth: 1500,
  hubTop: 40,
  liveWidth: 1560,
  liveTop: 30,
  searchWidth: 1560,
  searchTop: 30,
  tvWidth: 1560,
  tvTop: 28,
  captionAlign: "bottom-left",
};

export const squareLayout: DesktopLayout = {
  hubWidth: 984,
  hubTop: 345,
  liveWidth: 984,
  liveTop: 345,
  searchWidth: 984,
  searchTop: 345,
  tvWidth: 984,
  tvTop: 345,
  captionAlign: "above-frame",
};
