import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { Footage } from "../components/Footage";
import { linear } from "../motion";
import { beats, clipInPoints } from "../timeline";

export const ColdOpen: React.FC = () => {
  const frame = useCurrentFrame();
  const duration = beats.coldOpen.to - beats.coldOpen.from;
  const scale = 1.03 - 0.03 * linear(frame, 0, duration);
  return (
    <AbsoluteFill style={{ background: "#000" }}>
      <AbsoluteFill style={{ transform: `scale(${scale})`, transformOrigin: "50% 50%" }}>
        <Footage clip="splash" startFrom={clipInPoints.splash} />
      </AbsoluteFill>
    </AbsoluteFill>
  );
};
