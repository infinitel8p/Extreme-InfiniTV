import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { Caption } from "../components/Caption";
import { Footage } from "../components/Footage";
import { WindowFrame } from "../components/WindowFrame";
import { eased, linear } from "../motion";
import { millisToFrames } from "../theme";
import { beats, captions, clipInPoints } from "../timeline";
import { DesktopLayout } from "./layout";

export const Hub: React.FC<{ layout: DesktopLayout }> = ({ layout }) => {
  const frame = useCurrentFrame();
  const duration = beats.hub.to - beats.hub.from;
  const enterScale = eased(frame, 0, millisToFrames(600));
  const enterOpacity = eased(frame + 1, 0, millisToFrames(360));
  const drift = -10 * linear(frame, 0, duration);
  return (
    <AbsoluteFill>
      <WindowFrame width={layout.hubWidth} top={layout.hubTop} opacity={enterOpacity} scale={0.96 + 0.04 * enterScale} offsetY={drift}>
        <Footage clip="hub" startFrom={clipInPoints.hub} />
      </WindowFrame>
      <Caption
        eyebrow="EXTREME INFINITV"
        headline="Every playlist. One calm place."
        sub="Xtream Codes and M3U, side by side."
        align={layout.captionAlign}
        enterFrame={captions.hub.enter - beats.hub.from}
        exitFrame={captions.hub.exit - beats.hub.from}
      />
    </AbsoluteFill>
  );
};
