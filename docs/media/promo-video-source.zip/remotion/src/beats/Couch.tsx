import React from "react";
import { AbsoluteFill, Sequence, useCurrentFrame } from "remotion";
import { Caption } from "../components/Caption";
import { Footage } from "../components/Footage";
import { TvFrame } from "../components/TvFrame";
import { eased, linear } from "../motion";
import { beats, captions, clipInPoints, CROSSFADE_FRAMES, innerCuts } from "../timeline";
import { DesktopLayout } from "./layout";

export const Couch: React.FC<{ layout: DesktopLayout }> = ({ layout }) => {
  const frame = useCurrentFrame();
  const duration = beats.couch.to - beats.couch.from;
  const tvLiveStart = innerCuts.tvHomeToTvLive - beats.couch.from;
  const tvLiveOpacity = eased(frame, tvLiveStart, CROSSFADE_FRAMES);
  const scale = 1 + 0.03 * linear(frame, 0, duration);
  return (
    <AbsoluteFill>
      <TvFrame width={layout.tvWidth} top={layout.tvTop}>
        <AbsoluteFill style={{ transform: `scale(${scale})`, transformOrigin: "50% 50%" }}>
          <Sequence from={0} durationInFrames={tvLiveStart + CROSSFADE_FRAMES} layout="none">
            <Footage clip="tv-home" startFrom={clipInPoints.tvHome} />
          </Sequence>
          <Sequence from={tvLiveStart} layout="none">
            <AbsoluteFill style={{ opacity: tvLiveOpacity }}>
              <Footage clip="tv-live" startFrom={clipInPoints.tvLive} />
            </AbsoluteFill>
          </Sequence>
        </AbsoluteFill>
      </TvFrame>
      <Caption
        headline="Made for the remote."
        sub="D-pad first. Focus you can see from the sofa."
        align={layout.captionAlign}
        enterFrame={captions.couch.enter - beats.couch.from}
        exitFrame={captions.couch.exit - beats.couch.from}
      />
    </AbsoluteFill>
  );
};
