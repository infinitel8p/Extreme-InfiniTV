import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { Caption, CaptionAlign } from "../components/Caption";
import { Footage } from "../components/Footage";
import { PhoneFrame } from "../components/PhoneFrame";
import { eased } from "../motion";
import { millisToFrames } from "../theme";
import { beats, captions, clipInPoints } from "../timeline";

const PHONE_SCREEN_ASPECT = 1236 / 2744;

type PocketProps = {
  phoneHeight: number;
  phoneGap: number;
  groupCenterX: number;
  groupCenterY: number;
  captionAlign: CaptionAlign;
};

export const Pocket: React.FC<PocketProps> = ({ phoneHeight, phoneGap, groupCenterX, groupCenterY, captionAlign }) => {
  const frame = useCurrentFrame();
  const riseDuration = millisToFrames(600);
  const fadeDuration = millisToFrames(360);
  const stagger = millisToFrames(120);
  const leftRise = eased(frame, 0, riseDuration);
  const rightRise = eased(frame, stagger, riseDuration);
  const leftFade = eased(frame + 1, 0, fadeDuration);
  const rightFade = eased(frame + 1, stagger, fadeDuration);
  return (
    <AbsoluteFill>
      <div
        style={{
          position: "absolute",
          left: groupCenterX,
          top: groupCenterY,
          transform: "translate(-50%, -50%)",
          display: "flex",
          gap: phoneGap,
          alignItems: "center",
        }}
      >
        <PhoneFrame height={phoneHeight} screenAspect={PHONE_SCREEN_ASPECT} opacity={leftFade} offsetY={(1 - leftRise) * 24}>
          <Footage clip="phone-hub" startFrom={clipInPoints.phoneHub} />
        </PhoneFrame>
        <PhoneFrame height={phoneHeight} screenAspect={PHONE_SCREEN_ASPECT} opacity={rightFade} offsetY={(1 - rightRise) * 24}>
          <Footage clip="phone-livetv" startFrom={clipInPoints.phoneLivetv} />
        </PhoneFrame>
      </div>
      <Caption
        headline="And in your pocket."
        sub="Phone, tablet, TV, desktop, web. One codebase."
        align={captionAlign}
        enterFrame={captions.pocket.enter - beats.pocket.from}
        exitFrame={captions.pocket.exit - beats.pocket.from}
      />
    </AbsoluteFill>
  );
};
