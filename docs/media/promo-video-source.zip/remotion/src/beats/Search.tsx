import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { Caption } from "../components/Caption";
import { Footage } from "../components/Footage";
import { WindowFrame } from "../components/WindowFrame";
import { linear } from "../motion";
import { beats, captions, clipInPoints } from "../timeline";
import { DesktopLayout } from "./layout";

export const Search: React.FC<{ layout: DesktopLayout }> = ({ layout }) => {
  const frame = useCurrentFrame();
  const duration = beats.search.to - beats.search.from;
  const drift = -8 * linear(frame, 0, duration);
  return (
    <AbsoluteFill>
      <WindowFrame width={layout.searchWidth} top={layout.searchTop} offsetY={drift}>
        <Footage clip="search" startFrom={clipInPoints.search} />
      </WindowFrame>
      <Caption
        headline="Find anything in a keystroke."
        sub="Channels, movies, series, actors. Ctrl+K."
        align={layout.captionAlign}
        enterFrame={captions.search.enter - beats.search.from}
        exitFrame={captions.search.exit - beats.search.from}
      />
    </AbsoluteFill>
  );
};
