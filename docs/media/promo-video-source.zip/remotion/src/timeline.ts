import { secondsToFrames } from "./theme";

export const CROSSFADE_FRAMES = secondsToFrames(0.35);

export const beats = {
  coldOpen: { from: secondsToFrames(0), to: secondsToFrames(3.2) },
  hub: { from: secondsToFrames(3.2), to: secondsToFrames(8.0) },
  liveTv: { from: secondsToFrames(8.0), to: secondsToFrames(13.6) },
  couch: { from: secondsToFrames(13.6), to: secondsToFrames(20.4) },
  search: { from: secondsToFrames(20.4), to: secondsToFrames(24.2) },
  pocket: { from: secondsToFrames(24.2), to: secondsToFrames(28.6) },
  endCard: { from: secondsToFrames(28.6), to: secondsToFrames(33.0) },
};

export const TOTAL_FRAMES = beats.endCard.to;

export const clipInPoints = {
  splash: secondsToFrames(0.27),
  hub: secondsToFrames(0.9),
  livetv: secondsToFrames(2.0),
  epg: secondsToFrames(1.0),
  tvHome: secondsToFrames(0.5),
  tvLive: secondsToFrames(1.0),
  search: secondsToFrames(0.3),
  phoneHub: secondsToFrames(0),
  phoneLivetv: secondsToFrames(0),
};

export const captions = {
  hub: { enter: secondsToFrames(3.6), exit: secondsToFrames(7.6) },
  liveTv: { enter: secondsToFrames(8.4), exit: secondsToFrames(13.2) },
  couch: { enter: secondsToFrames(14.0), exit: secondsToFrames(20.0) },
  search: { enter: secondsToFrames(20.8), exit: secondsToFrames(23.8) },
  pocket: { enter: secondsToFrames(24.7), exit: secondsToFrames(28.2) },
};

export const innerCuts = {
  liveTvToEpg: secondsToFrames(11.4),
  tvHomeToTvLive: secondsToFrames(17.4),
};

export const sfxFrames = {
  impact: secondsToFrames(1.33),
  uiSelect: secondsToFrames(10.0),
  whooshCouch: secondsToFrames(13.5),
  whooshPocket: secondsToFrames(24.1),
  uiNavTicks: [14.0, 14.9, 15.6, 16.3, 17.0, 18.1, 18.8, 19.5].map(secondsToFrames),
};

export const musicStartSeconds = 14;
