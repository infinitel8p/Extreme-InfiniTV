import React from "react";
import { Audio, interpolate, Sequence, staticFile } from "remotion";
import { FPS, secondsToFrames } from "./theme";
import { musicStartSeconds, sfxFrames, TOTAL_FRAMES } from "./timeline";

const decibelsToGain = (decibels: number): number => Math.pow(10, decibels / 20);

const MUSIC_PREGAIN_DB = 1.7;
const MUSIC_GAIN = 1;

const levels = {
  impact: decibelsToGain(MUSIC_PREGAIN_DB - 14),
  whoosh: decibelsToGain(MUSIC_PREGAIN_DB - 16),
  uiNav: decibelsToGain(-9),
  uiSelect: decibelsToGain(-12),
};

const MUSIC_FADE_IN = secondsToFrames(0.5);
const MUSIC_FADE_OUT = secondsToFrames(1.5);

const musicVolume = (frame: number): number => {
  const fadeIn = interpolate(frame, [0, MUSIC_FADE_IN], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  const fadeOut = interpolate(frame, [TOTAL_FRAMES - MUSIC_FADE_OUT, TOTAL_FRAMES], [1, 0], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
  return MUSIC_GAIN * fadeIn * fadeOut;
};

const leadingSilenceTrim = secondsToFrames(0.3);

const Sfx: React.FC<{ file: string; at: number; volume: number; trimBefore?: number }> = ({ file, at, volume, trimBefore }) => (
  <Sequence from={at} layout="none">
    <Audio src={staticFile(`audio/sfx/${file}`)} volume={volume} trimBefore={trimBefore} />
  </Sequence>
);

export const Soundtrack: React.FC = () => {
  return (
    <>
      <Audio src={staticFile("audio/music.wav")} trimBefore={musicStartSeconds * FPS} volume={musicVolume} />
      <Sfx file="impact-low.mp3" at={sfxFrames.impact} volume={levels.impact} trimBefore={leadingSilenceTrim} />
      <Sfx file="ui-select.wav" at={sfxFrames.uiSelect} volume={levels.uiSelect} />
      <Sfx file="whoosh-soft.mp3" at={sfxFrames.whooshCouch} volume={levels.whoosh} trimBefore={leadingSilenceTrim} />
      <Sfx file="whoosh-soft.mp3" at={sfxFrames.whooshPocket} volume={levels.whoosh} trimBefore={leadingSilenceTrim} />
      {sfxFrames.uiNavTicks.map((tickFrame) => (
        <Sfx key={tickFrame} file="ui-nav.wav" at={tickFrame} volume={levels.uiNav} />
      ))}
    </>
  );
};
