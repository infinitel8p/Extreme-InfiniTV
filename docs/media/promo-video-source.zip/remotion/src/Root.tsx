import React from "react";
import { Composition } from "remotion";
import { Promo } from "./Promo";
import { FPS } from "./theme";
import { TOTAL_FRAMES } from "./timeline";

export const RemotionRoot: React.FC = () => {
  return (
    <>
      <Composition
        id="promo"
        component={Promo}
        width={1920}
        height={1080}
        fps={FPS}
        durationInFrames={TOTAL_FRAMES}
        defaultProps={{ format: "landscape" }}
      />
      <Composition
        id="promo-square"
        component={Promo}
        width={1080}
        height={1080}
        fps={FPS}
        durationInFrames={TOTAL_FRAMES}
        defaultProps={{ format: "square" }}
      />
    </>
  );
};
