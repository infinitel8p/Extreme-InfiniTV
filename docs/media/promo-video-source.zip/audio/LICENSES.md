# Audio assets for the Extreme InfiniTV product video

Collected 2026-09-01. Every music candidate and both new sound effects come from freesound.org, where each sound page states its licence explicitly (the licence text and the creativecommons.org URL were read from the sound page before download). Files were fetched from freesound's public HQ preview endpoint (`https://cdn.freesound.org/previews/<prefix>/<id>_<userid>-hq.mp3`), the same route the project used for `ui-launch.wav`. Originals (WAV/FLAC, often 320 kbps or lossless) require a freesound login; swap them in for a lossless master if wanted, the licence is identical.

Licence texts used below:

- **CC0 1.0 Universal** (freesound label "Creative Commons 0"): <https://creativecommons.org/publicdomain/zero/1.0/>. Public domain dedication. No attribution required (credit is still a courtesy).
- **CC BY 4.0** (freesound label "Attribution 4.0"): <https://creativecommons.org/licenses/by/4.0/>. Commercial use and modification allowed; the credit line given per file must appear in the video description or end card, plus a note if the track was edited (trimmed/faded).

Every file was validated with `ffprobe`; loudness via `ffmpeg -af ebur128`; energy / spectral-centroid timelines, a rough tempo estimate and a percussiveness score via `analyze.py` in this folder (numpy over decoded PCM; the 5 s timeline is RMS in dBFS and amplitude-weighted spectral centroid in Hz).

Nothing was auditioned by ear. Ranking is based on the creators' own descriptions, tags, and the measured profiles; please listen before locking the pick.

---

## Music candidates

### candidate-1.mp3 (top pick)

- **Title**: Unpretentious Reveal (no drums)
- **Author**: SondreDrakensson (Sondre Drakensson)
- **Source URL**: <https://freesound.org/people/SondreDrakensson/sounds/529381/>
- **Licence (exact)**: Creative Commons 0 (CC0 1.0 Universal), <https://creativecommons.org/publicdomain/zero/1.0/>
- **Attribution required**: none. Courtesy credit: `"Unpretentious Reveal (no drums)" by Sondre Drakensson (freesound.org), CC0`
- **Author's description**: "This is a minimalistic unpretentious promo track made with technology and vehicles in mind." Drum-less alternate of sound 529380.
- **File**: MP3 (HQ preview), 44.1 kHz stereo, 59.45 s, sha256 `860f61a21b78f5bae2f6ca7a16c5b941abee6a99c6ecbddd3228b493a7317c8c`. Original on freesound: WAV 320 kbps-equivalent, 0:59.416.
- **Measurements**: integrated -19.0 LUFS, LRA 4.2 LU, true peak -0.5 dBTP. Percussive onsets 1.7 % (very low). Energy rises gently (+0.9 dB first third to last third) and peaks around 45-50 s. Tempo autocorrelation strongest at ~129 BPM with a half-time reading of ~65 BPM, i.e. it likely sits as a slow pulse that can be felt at 65 or 129.
- **Timeline (t: dBFS / centroid Hz)**: 0:-21.2/503, 5:-19.3/475, 10:-19.5/490, 15:-19.3/2393, 20:-19.3/1985, 25:-20.3/807, 30:-21.7/594, 35:-21.0/520, 40:-18.2/574, 45:-17.2/530, 50:-19.6/914, 55:-21.7/2459. Reads as: low, warm pad intro; brighter texture enters at ~15 s; drops back; a fuller swell at 40-50 s; short bright tail.
- **Why it fits**: written as a promo/reveal bed for technology products, explicitly minimal, no drums, CC0 (zero attribution overhead for store trailers and social cuts), 59 s so a 30-40 s cut with a natural swell at ~45 s is easy. Closest to the "Apple TV / Linear product film" brief of everything found.
- **Caveats**: tempo estimate is at the edge of the 90-120 BPM ask (either 65 or 129 depending on how the pulse is felt). If the video needs a light pulse, sound 529380 (same author, same CC0, same URL pattern `529/529380_6628165-hq.mp3`) is the identical arrangement with drums (measured -16.1 LUFS, 3.6 % percussive, ~96 BPM); it was evaluated but not kept because the brief asks for no drums.

### candidate-2.mp3 (rank 2)

- **Title**: Overlook (uplifting ambient loop)
- **Author**: SondreDrakensson (Sondre Drakensson)
- **Source URL**: <https://freesound.org/people/SondreDrakensson/sounds/506495/>
- **Licence (exact)**: Creative Commons 0 (CC0 1.0 Universal), <https://creativecommons.org/publicdomain/zero/1.0/>
- **Attribution required**: none. Author writes: "You don't need to credit me, but if you do, use the name Sondre Drakensson."
- **Author's description**: "A slightly uplifting ambient loop inspired by Mirror's Edge."
- **File**: MP3, 44.1 kHz stereo, 78.05 s, sha256 `5fd494a1c9d46fb6bdab080066b1c0e9d1751c4b7ae27bb240fa67220dfc9987`.
- **Measurements**: -16.8 LUFS, LRA 2.5 LU, true peak -3.3 dBTP. Percussive 3.0 % (light pulse). Tempo candidates 60 / 117 / 123 BPM (strong periodicity 0.92), so about 117-120 BPM or its half. Energy flat (-0.5 dB), it is a loop: brightness lifts at 40-55 s (centroid 700 -> 1300 Hz) which is the only "build" moment.
- **Timeline**: 0:-18.8/868, 5:-18.3/821, 10:-18.7/847, 15:-20.5/714, 20:-18.9/778, 25:-18.8/785, 30:-17.5/743, 35:-19.4/716, 40:-18.8/1281, 45:-18.7/1332, 50:-17.8/1138, 55:-17.4/999, 60:-18.6/845, 65:-19.4/882, 70:-20.5/761.
- **Why it fits**: same author, CC0, clean modern synth-ambient in the right tempo range, calm and slightly hopeful (Mirror's Edge reference = clean, minimal, white-and-accent aesthetic, a good match for the slate + fuchsia brand). Loops seamlessly so any 35-40 s window works.
- **Caveats**: no real arc, so the edit has to supply the build (e.g. start at ~25 s so the 40-55 s lift lands on the feature montage).

### candidate-3.mp3 (rank 3)

- **Title**: Ambient, Pad Piano - Event Horizon
- **Author**: Andrewkn
- **Source URL**: <https://freesound.org/people/Andrewkn/sounds/827922/>
- **Licence (exact)**: Attribution 4.0 (CC BY 4.0), <https://creativecommons.org/licenses/by/4.0/>
- **Attribution required**: yes. Use: `"Ambient, Pad Piano - Event Horizon" by Andrewkn, https://freesound.org/s/827922/, licensed under CC BY 4.0 (https://creativecommons.org/licenses/by/4.0/). Trimmed and level-adjusted.`
- **Author's description**: "Calm... Ambient serenity. Drift away with beautiful, expansive pads. 90 Bpm. No pre-made loops used. Not used ai-generated."
- **File**: MP3, 44.1 kHz stereo, 96.03 s, sha256 `07fafc19a559ffafdc0c6dbfc117b56ef61d0f8a8a36b8706de0330cbe84b063`.
- **Measurements**: -25.7 LUFS (quiet, needs ~+8 dB normalisation), LRA 6.8 LU, true peak -13.0 dBTP. Percussive 0.0 %. Energy essentially flat after a 5 s fade-in (-2.9 dB over the piece), fades out from ~85 s. Author states 90 BPM (in range); the autocorrelation found no beat, consistent with a beatless pad piece.
- **Timeline**: 0:-42.7/764, 5:-29.2/1128, 10:-27.7/1227, 15:-27.1/1085, 20:-27.2/1166, 25:-28.3/1066, 30:-28.2/1196, 35:-28.9/1087, 40:-28.0/1104, 45:-27.3/882, 50:-28.4/1071, 55:-28.0/978, 60:-29.7/1076, 65:-27.6/958, 70:-31.0/1065, 75:-27.6/1004, 80:-30.6/945, 85:-38.8/1010, 90:-52.8/1041.
- **Why it fits**: exactly "soft synth pads or piano", zero drums, calm and premium, human-made. Best choice if the video wants an under-bed that never competes with UI sound effects and voice-over.
- **Caveats**: CC BY (credit line needed), no build at all, low level (fine, just normalise).

### candidate-4.mp3 (runner-up, kept for the "gentle build" requirement)

- **Title**: Ambient Documentary Build Up #02
- **Author**: tyops
- **Source URL**: <https://freesound.org/people/tyops/sounds/437317/>
- **Licence (exact)**: Attribution 4.0 (CC BY 4.0), <https://creativecommons.org/licenses/by/4.0/>
- **Attribution required**: yes. Use: `"Ambient Documentary Build Up #02" by tyops, https://freesound.org/s/437317/, licensed under CC BY 4.0 (https://creativecommons.org/licenses/by/4.0/). Trimmed.`
- **Author's description**: "Starts more calmly and then gets brighter with the strings. Software: Cubase 8."
- **File**: MP3, 48 kHz stereo, 110.04 s, sha256 `baf2c02d91e7aedbe9d08230dd76e6c2485ceead56e69c909d4258524ca19728`.
- **Measurements**: -15.6 LUFS, LRA 18.1 LU (wide), true peak -0.5 dBTP. Percussive 2.5 %. The only candidate with a real arc: +10.4 dB from first to last third, quiet pad intro to 25 s, steady mid from 25-75 s, strings peak at 80-100 s. Tempo ~72 BPM (144 half-time).
- **Timeline**: 0:-35.8/828, 5:-32.6/733, 10:-31.1/670, 15:-31.0/553, 20:-29.1/484, 25:-19.0/295, 30:-17.1/348, 35:-17.8/370, 40:-16.6/357, 45:-18.9/401, 50:-18.0/560, 55:-17.7/910, 60:-16.5/881, 65:-16.6/874, 70:-17.4/1313, 75:-19.3/1626, 80:-12.4/1490, 85:-12.8/1653, 90:-11.9/1648, 95:-12.7/1928, 100:-13.3/1935, 105:-24.8/1033.
- **Why it is only a runner-up**: it delivers the build the brief asks for, but the payoff is orchestral strings at documentary-trailer intensity, which drifts away from "cinematic-minimal" toward "epic". Usable if the 35-40 s cut is taken from 25-65 s (calm plateau) with a fade before the string climax. Tempo is below the 90-120 range.

### Evaluated and rejected (not downloaded into this folder)

- 746454 "Spark of Inspiration" (ViraMiller, CC BY 4.0): loud (-12.4 LUFS), bright (centroid ~2300 Hz), "uplifting and motivational", reads as stock corporate.
- 752342 "Ascension" (Twotrickpony, CC BY 4.0): flat celestial drone, sci-fi flavour.
- 560442 "Pad Background Music" (Migfus20, CC BY 4.0): author describes it as "sad, and a little uneasy/insecure".
- 384202 "Slow Cinematic Music" (DeVern, CC0): "semi epic", front-loaded energy, -11.9 LUFS.
- 831993 "DreamyAmbientSoundtrack" (Akkaittou, CC BY 4.0): nostalgic and "somehow painful" per the author.
- 529380 "Unpretentious Reveal" (with drums): see candidate-1 caveats.

### Ranking summary

1. candidate-1, Unpretentious Reveal (no drums): purpose-built minimal tech promo bed, no drums, gentle swell at 45 s, CC0.
2. candidate-2, Overlook: clean modern synth ambient at ~117-120 BPM, CC0, seamless loop, needs the edit to provide the arc.
3. candidate-3, Event Horizon: purest pads-and-piano calm, 90 BPM, CC BY (credit needed), no build.
4. candidate-4, Ambient Documentary Build Up #02: strongest build, but the climax is orchestral rather than minimal, CC BY.

---

## Sound effects (`sfx/`)

### Project UI sounds copied from `/home/claude/xtream/public/sounds/`

- **ui-launch.wav**: "Chord Reverse 1-Fmin" by CAT-FOX_ALEX. Source <https://freesound.org/people/CAT-FOX_ALEX/sounds/863888/>. Licence: CC0 (public domain), per `public/sounds/README.md`. Processed in-project: trimmed to first 3.2 s, 600 ms fade-out, peak-normalised to 0.11, sourced from the HQ preview MP3. 44.1 kHz stereo 16-bit, 3.20 s. No attribution required. sha256 `54f9a79a5d207d7d0aaeb7e0eb00d39c18c320d69e1b29946bf597c9eea20ccc`.
- **ui-nav.wav** (0.06 s), **ui-select.wav** (0.14 s), **ui-confirm.wav** (0.26 s): 48 kHz mono 16-bit. Provenance: NOT third-party recordings. They are synthesised procedurally by `/home/claude/xtream/src/scripts/make-ui-sounds.mjs` (additive sine partials with attack/decay envelopes; its header says: "Synthesizes ui-nav / ui-select / ui-confirm in public/sounds/ (ui-launch.wav is a recording, see the README there)"). The README in `public/sounds/` does not list them and git history has a single commit (`46a7b98`) adding all four files with no provenance note. Because they are generated by the project's own code, they are covered by the repository licence, GPL-3.0-or-later (`LICENSE`, `package.json`), i.e. the project owns them outright and can use them freely in its own video. sha256: nav `447a133e46c2581ea498127268755ea2573c4d5af388de4fb828762ccfc84adc`, select `dbdcf4fe6a1ae0c5d9fcbfa1b6768bed0ee41d0b84318760a34cd371d4fdc8bd`, confirm `ae59d9d3b95acd4b8df37103de390306c0933d37b9b4cd1e743e80889826e593`.

### whoosh-soft.mp3 (transition)

- **Title**: Whoosh stereo light (transition)
- **Author**: xkeril
- **Source URL**: <https://freesound.org/people/xkeril/sounds/701104/>
- **Licence (exact)**: Creative Commons 0 (CC0 1.0 Universal), <https://creativecommons.org/publicdomain/zero/1.0/>
- **Attribution required**: none. Courtesy credit: `"Whoosh stereo light (transition)" by xkeril (freesound.org), CC0`
- **Author's description**: "An air woosh perfect for transition from left to right, like youtube video. Light soft and natural whoosh. It was made with a pump and some reverb, recorded in real stereo with a zoom h5n."
- **File**: MP3 (HQ preview), 48 kHz stereo, 2.35 s, -16.6 LUFS, true peak -4.0 dBTP, energy peaks at ~1 s then decays. sha256 `791bf392615c81ef7b0fd1a92fa39b847241ae0f995669f22573763edbaef07b`. Original: 48 kHz WAV, 0:02.316.

### impact-low.mp3 (logo reveal)

- **Title**: Low impact.wav
- **Author**: AudioPapkin
- **Source URL**: <https://freesound.org/people/AudioPapkin/sounds/430978/>
- **Licence (exact)**: Creative Commons 0 (CC0 1.0 Universal), <https://creativecommons.org/publicdomain/zero/1.0/>
- **Attribution required**: none. Courtesy credit: `"Low impact" by AudioPapkin (freesound.org), CC0`
- **Author's description**: "Low impact, is perfect for cinematic uses, video games."
- **File**: MP3 (HQ preview), 44.1 kHz stereo, 5.25 s, -12.6 LUFS, true peak -0.3 dBTP, hit at ~0-2 s with a ~3 s low tail (spectral centroid ~240 Hz, so it is genuinely sub-heavy). sha256 `bcf27da9931daf7030a8a4954235e1cf91eaecd1a7da254b9e2b748aa3c55a39`. Original: 44.1 kHz WAV, 0:05.223. Pull the gain down ~6 dB against the music bed for a "soft" boom.

---

## Suggested credit block (only what is legally required, plus courtesy lines)

Required (if candidate-3 or candidate-4 is used):

```
Music: "Ambient, Pad Piano - Event Horizon" by Andrewkn, https://freesound.org/s/827922/, CC BY 4.0, https://creativecommons.org/licenses/by/4.0/ (trimmed)
Music: "Ambient Documentary Build Up #02" by tyops, https://freesound.org/s/437317/, CC BY 4.0, https://creativecommons.org/licenses/by/4.0/ (trimmed)
```

Courtesy (CC0 material, optional):

```
Music: "Unpretentious Reveal (no drums)" / "Overlook" by Sondre Drakensson (freesound.org), CC0
SFX: "Whoosh stereo light" by xkeril, "Low impact" by AudioPapkin, "Chord Reverse 1-Fmin" by CAT-FOX_ALEX (freesound.org), CC0
```

## Not obtained / limitations

- Lossless originals: freesound gates the original WAV/FLAC downloads behind a login; only the public 128-192 kbps HQ preview MP3s were fetched (same approach the project already uses). No attempt was made to bypass the login.
- freepd.com, Pixabay and the Free Music Archive were not needed once four freesound candidates with explicit CC0 / CC BY 4.0 licence statements were confirmed; Pixabay in particular uses its own Content Licence (not CC), so it would not have met the CC0 / CC BY requirement anyway.
- No listening test was possible in this environment; the ranking relies on descriptions and signal measurements.
