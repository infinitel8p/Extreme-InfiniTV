// Records product-video clips of the running Extreme InfiniTV web build.
// Deterministic capture: Chromium headless shell with BeginFrame control + virtual time, so every
// frame is exactly 1/60 s of app time no matter how slow the machine renders.
// Usage: node record.mjs [clip ...]   (no args = every clip)
import { createRequire } from "node:module"
import { mkdir, rm, writeFile, copyFile, readFile } from "node:fs/promises"
import { execFile } from "node:child_process"
import { promisify } from "node:util"
import path from "node:path"
import { fileURLToPath } from "node:url"
import {
  DISPLAY_TIMEZONE,
  artworkSvgByPath,
  buildSchedule,
  buildSeed,
  buildXmltv,
  playerApiResponse,
} from "./fixture.mjs"

const require = createRequire("/home/claude/xtream/package.json")
const { chromium } = require("playwright")
const execFileAsync = promisify(execFile)

export const BASE_URL = process.env.XT_BASE_URL || "http://127.0.0.1:4321"
const CHROMIUM_PATH = process.env.XT_CHROMIUM || "/opt/pw-browsers/chromium-1194/chrome-linux/chrome"
const HEADLESS_SHELL_PATH = process.env.XT_HEADLESS_SHELL || "/opt/pw-browsers/chromium_headless_shell-1194/chrome-linux/headless_shell"
const ASSETS_DIR = "/home/claude/video-assets"
const FOOTAGE_DIR = path.join(ASSETS_DIR, "footage")
const STILLS_DIR = path.join(ASSETS_DIR, "stills")
const FRAMES_ROOT = path.join(ASSETS_DIR, "frames")
const FPS = 60
const FRAME_MS = 1000 / FPS
export const DESKTOP_VIEWPORT = { width: 1920, height: 1080 }
export const PHONE_VIEWPORT = { width: 412, height: 915 }
export const TIMEZONE = DISPLAY_TIMEZONE
const LIVE_STREAM_DELAY_MS = 25_000

const DETERMINISTIC_FLAGS = [
  "--enable-begin-frame-control",
  "--run-all-compositor-stages-before-draw",
  "--disable-new-content-rendering-timeout",
  "--disable-threaded-animation",
  "--disable-threaded-scrolling",
  "--disable-checker-imaging",
  "--disable-image-animation-resync",
  "--disable-features=PaintHolding",
  "--autoplay-policy=no-user-gesture-required",
  "--force-color-profile=srgb",
]

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms))
const startedAtMs = Date.now()
const logPhase = (message) => console.log(`[${((Date.now() - startedAtMs) / 1000).toFixed(1)}s] ${message}`)
const easeInOut = (t) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2)
const framesFor = (ms) => Math.max(1, Math.round(ms / FRAME_MS))

const nowMs = Date.now()
const schedule = buildSchedule(nowMs)
const xmltvText = buildXmltv(schedule)
const seed = buildSeed(nowMs)
const clipNotes = []
const stillFiles = {}

// ---------------------------------------------------------------------------
// Artwork rasterisation (SVG -> PNG via a throwaway regular-headless page)
// ---------------------------------------------------------------------------
export async function rasterizeArtwork(browser) {
  const context = await browser.newContext({ viewport: { width: 1280, height: 720 }, deviceScaleFactor: 1 })
  const page = await context.newPage()
  const pngByPath = new Map()
  for (const [assetPath, { svg, width, height }] of artworkSvgByPath()) {
    await page.setContent(
      `<!doctype html><html><head><style>
        html, body { margin: 0; background: transparent; }
        #art { width: ${width}px; height: ${height}px; display: block; }
      </style></head><body><div id="art">${svg}</div></body></html>`
    )
    const png = await page.locator("#art").screenshot({ omitBackground: true, type: "png" })
    pngByPath.set(assetPath, png)
  }
  await context.close()
  return pngByPath
}

// ---------------------------------------------------------------------------
// Routes + seeding
// ---------------------------------------------------------------------------
export async function installRoutes(context, pngByPath) {
  await context.route("**/*", async (route) => {
    const url = new URL(route.request().url())
    if (url.hostname === "127.0.0.1" || url.hostname === "localhost") return route.continue()
    if (url.hostname === "api.github.com") {
      return route.fulfill({ status: 200, contentType: "application/json", body: "[]" })
    }
    if (url.hostname !== "fixtures.invalid") {
      return route.fulfill({ status: 404, contentType: "text/plain", body: "" })
    }
    if (url.pathname === "/player_api.php") {
      const body = playerApiResponse(url.searchParams, schedule, Date.now())
      return route.fulfill({ status: 200, contentType: "application/json", body: JSON.stringify(body) })
    }
    if (url.pathname === "/xmltv.php") {
      return route.fulfill({ status: 200, contentType: "application/xml", body: xmltvText })
    }
    const png = pngByPath.get(url.pathname)
    if (png) {
      return route.fulfill({ status: 200, contentType: "image/png", body: png, headers: { "cache-control": "public, max-age=86400" } })
    }
    if (url.pathname.startsWith("/live/") || url.pathname.startsWith("/movie/") || url.pathname.startsWith("/series/")) {
      // Hang the stream request so the player sits in its connecting state instead of erroring.
      await sleep(LIVE_STREAM_DELAY_MS)
      return route.fulfill({ status: 404, contentType: "text/plain", body: "" }).catch(() => {})
    }
    return route.fulfill({ status: 404, contentType: "text/plain", body: "" })
  })
}

export async function seedContext(context) {
  await context.addInitScript(
    ({ playlists, prefs }) => {
      try {
        if (!localStorage.getItem("xt_playlists")) {
          localStorage.setItem("xt_playlists", JSON.stringify(playlists))
          localStorage.setItem("xt_prefs", JSON.stringify(prefs))
          localStorage.setItem("xt_theme", "dark")
          localStorage.setItem("xt_locale", "en")
          localStorage.setItem("xt_last_seen_version", "99.0.0")
          localStorage.setItem("xt_receiver_boot", "0")
          localStorage.setItem("xt_tv_effects", "full")
        }
      } catch {}
      try {
        if (localStorage.getItem("xt_demo_show_splash") !== "1") sessionStorage.setItem("xt_splash_done", "1")
      } catch {}
    },
    seed
  )
}

// ---------------------------------------------------------------------------
// Raw CDP client (Node's WebSocket): the 1 MB+ screenshot per frame must not pass through
// Playwright's channel layer, which retains it and exhausts the heap over a few hundred frames.
// ---------------------------------------------------------------------------
let nextDebugPort = 9333

class RawCdp {
  constructor(url) {
    this.url = url
    this.nextId = 1
    this.callbacks = new Map()
    this.listeners = new Map()
  }

  async connect() {
    this.socket = new WebSocket(this.url)
    await new Promise((resolve, reject) => {
      this.socket.addEventListener("open", resolve, { once: true })
      this.socket.addEventListener("error", reject, { once: true })
    })
    this.socket.addEventListener("message", (event) => {
      const message = JSON.parse(event.data)
      if (message.id) {
        const callback = this.callbacks.get(message.id)
        this.callbacks.delete(message.id)
        if (!callback) return
        if (message.error) callback.reject(new Error(message.error.message))
        else callback.resolve(message.result)
        return
      }
      const key = `${message.sessionId || ""}:${message.method}`
      for (const listener of this.listeners.get(key) || []) listener(message.params)
    })
    this.socket.addEventListener("close", () => {
      for (const callback of this.callbacks.values()) callback.reject(new Error("CDP socket closed"))
      this.callbacks.clear()
    })
  }

  send(method, params = {}, sessionId) {
    const id = this.nextId++
    return new Promise((resolve, reject) => {
      this.callbacks.set(id, { resolve, reject })
      try {
        this.socket.send(JSON.stringify({ id, method, params, sessionId }))
      } catch (error) {
        this.callbacks.delete(id)
        reject(error)
      }
    })
  }

  once(sessionId, method) {
    return new Promise((resolve) => {
      const key = `${sessionId || ""}:${method}`
      const listener = (params) => {
        this.listeners.set(key, (this.listeners.get(key) || []).filter((entry) => entry !== listener))
        resolve(params)
      }
      this.listeners.set(key, [...(this.listeners.get(key) || []), listener])
    })
  }

  close() {
    try { this.socket.close() } catch {}
  }
}

/** Page-scoped view of the raw client: the same send/once surface, bound to one session id. */
function sessionClient(raw, sessionId) {
  return {
    send: (method, params = {}) => raw.send(method, params, sessionId),
    once: (method) => raw.once(sessionId, method),
  }
}

// ---------------------------------------------------------------------------
// Frame pump (keeps the page rendering in near real time while it loads / settles)
// ---------------------------------------------------------------------------
const PUMP_FRAME_TIMEOUT_MS = 4000
const RECORD_FRAME_TIMEOUT_MS = 45_000

/** cdp.send with a deadline; a beginFrame that never answers must not wedge the run. */
async function sendWithTimeout(cdp, method, params, timeoutMs) {
  let timer
  const timeout = new Promise((_, reject) => {
    timer = setTimeout(() => reject(new Error(`${method} timed out after ${timeoutMs} ms`)), timeoutMs)
  })
  try {
    return await Promise.race([cdp.send(method, params), timeout])
  } finally {
    clearTimeout(timer)
  }
}

class FramePump {
  constructor(cdp) {
    this.cdp = cdp
    this.running = false
    this.wedged = false
  }

  start() {
    if (this.running || this.wedged) return
    this.running = true
    this.loop = (async () => {
      while (this.running) {
        try {
          await sendWithTimeout(this.cdp, "HeadlessExperimental.beginFrame", { interval: FRAME_MS, noDisplayUpdates: false }, PUMP_FRAME_TIMEOUT_MS)
        } catch (error) {
          if (String(error.message).includes("timed out")) {
            logPhase(`pump wedged: ${error.message}`)
            this.wedged = true
            this.running = false
            return
          }
        }
        await sleep(16)
      }
    })()
  }

  async stop() {
    if (!this.running) return
    this.running = false
    await this.loop
  }
}

/** A page plus its CDP session and pump; every recorded page goes through here. */
export async function openPage(context) {
  const page = await context.newPage()
  const probe = await context.newCDPSession(page)
  const { targetInfo } = await probe.send("Target.getTargetInfo")
  await probe.detach().catch(() => {})
  const raw = context.__raw
  const { sessionId } = await raw.send("Target.attachToTarget", { targetId: targetInfo.targetId, flatten: true })
  const cdp = sessionClient(raw, sessionId)
  await cdp.send("HeadlessExperimental.enable").catch(() => {})
  const pump = new FramePump(cdp)
  pump.start()
  return { page, cdp, pump, sessionId }
}

export async function closePage(handle) {
  await Promise.race([handle.pump.stop(), sleep(PUMP_FRAME_TIMEOUT_MS + 1000)])
  await Promise.race([handle.page.close().catch(() => {}), sleep(3000)])
}

/** Closes a browser, SIGKILLing it if a wedged renderer keeps the graceful path from returning. */
export async function closeBrowser(browser, context) {
  context?.__raw?.close()
  const closed = await Promise.race([browser.close().then(() => true).catch(() => false), sleep(8000).then(() => false)])
  if (!closed) {
    logPhase("browser did not close gracefully; killing")
    try { browser.process()?.kill("SIGKILL") } catch {}
    await sleep(500)
  }
}

/** Fresh browser + seeded, warmed context. One per clip: a wedged renderer never leaks into the next recording. */
export async function openWarmContext({ pngByPath, launchArgs, contextOptions }) {
  const port = nextDebugPort++
  const browser = await chromium.launch({ executablePath: HEADLESS_SHELL_PATH, headless: true, args: [...DETERMINISTIC_FLAGS, ...launchArgs, `--remote-debugging-port=${port}`] })
  browser.on("disconnected", () => logPhase("browser disconnected"))
  const version = await (await fetch(`http://127.0.0.1:${port}/json/version`)).json()
  const raw = new RawCdp(version.webSocketDebuggerUrl)
  await raw.connect()
  const context = await browser.newContext(contextOptions)
  context.__raw = raw
  await installRoutes(context, pngByPath)
  await seedContext(context)
  const warm = await openPage(context)
  await warmContext(warm.page)
  await closePage(warm)
  return { browser, context }
}

// ---------------------------------------------------------------------------
// Deterministic recorder
// ---------------------------------------------------------------------------
export class Recorder {
  constructor(handle, name, { networkPolicy = "pauseIfNetworkFetchesPending" } = {}) {
    this.handle = handle
    this.name = name
    this.networkPolicy = networkPolicy
    this.dir = path.join(FRAMES_ROOT, name)
    this.frameCount = 0
    this.pending = []
    this.writes = []
    this.markers = []
  }

  async start() {
    await rm(this.dir, { recursive: true, force: true })
    await mkdir(this.dir, { recursive: true })
    await Promise.race([this.handle.pump.stop(), sleep(PUMP_FRAME_TIMEOUT_MS + 1000)])
    const { virtualTimeTicksBase } = await this.handle.cdp.send("Emulation.setVirtualTimePolicy", { policy: "pause" })
    // Frame timestamps must track virtual time, or rAF/CSS animation clocks run on wall time
    // and a 300 ms transition finishes within two or three captured frames.
    this.ticksBase = virtualTimeTicksBase
    logPhase(`${this.name}: recording started`)
  }

  /** Records a named moment at the current clip time, for the manifest. */
  mark(label) {
    this.markers.push({ label, atSec: Number((this.frameCount / FPS).toFixed(2)) })
  }

  /** Fire-and-forget page interaction; awaited at stop(). Input acks can need a frame, so never await inline. */
  act(promiseFactory) {
    this.pending.push(Promise.resolve().then(promiseFactory).catch((error) => console.warn(`[${this.name}] action failed: ${error.message}`)))
  }

  press(key) {
    this.act(() => this.handle.page.keyboard.press(key))
  }

  async frame() {
    const { cdp } = this.handle
    const expired = cdp.once("Emulation.virtualTimeBudgetExpired")
    await cdp.send("Emulation.setVirtualTimePolicy", { policy: this.networkPolicy, budget: FRAME_MS, maxVirtualTimeTaskStarvationCount: 100_000 })
    await Promise.race([expired, sleep(RECORD_FRAME_TIMEOUT_MS)])
    let result
    try {
      result = await sendWithTimeout(
        cdp,
        "HeadlessExperimental.beginFrame",
        { frameTimeTicks: this.ticksBase + (this.frameCount + 1) * FRAME_MS, interval: FRAME_MS, noDisplayUpdates: false, screenshot: { format: "png" } },
        RECORD_FRAME_TIMEOUT_MS
      )
    } catch (error) {
      logPhase(`${this.name}: frame ${this.frameCount} failed (${error.message}); repeating previous frame`)
      result = {}
    }
    const file = path.join(this.dir, `f_${String(this.frameCount).padStart(5, "0")}.png`)
    if (result.screenshotData) {
      this.lastFrameFile = file
      this.writes.push(writeFile(file, Buffer.from(result.screenshotData, "base64")))
    } else if (this.lastFrameFile) {
      this.writes.push(copyFile(this.lastFrameFile, file))
    }
    this.frameCount++
    if (this.frameCount % 60 === 0) logPhase(`${this.name}: ${this.frameCount} frames`)
    if (this.writes.length > 8) {
      await Promise.all(this.writes)
      this.writes = []
    }
  }

  async advance(ms) {
    const count = framesFor(ms)
    for (let index = 0; index < count; index++) await this.frame()
  }

  async pressSlowly(keys, gapMs) {
    for (const key of keys) {
      this.press(key)
      await this.advance(gapMs)
    }
  }

  async typeSlowly(text, gapMs) {
    for (const character of text) {
      this.press(character)
      await this.advance(gapMs)
    }
  }

  async glideMouse(from, to, durationMs) {
    const count = framesFor(durationMs)
    for (let step = 1; step <= count; step++) {
      const eased = easeInOut(step / count)
      const x = from.x + (to.x - from.x) * eased
      const y = from.y + (to.y - from.y) * eased
      this.act(() => this.handle.page.mouse.move(x, y))
      await this.frame()
    }
  }

  /** Eased scroll driven by the page's own requestAnimationFrame, so it advances one step per captured frame. */
  async smoothScroll(selector, { dx = 0, dy = 0, durationMs = 4000 }) {
    this.act(() =>
      this.handle.page.evaluate(
        ({ selector, dx, dy, durationMs }) =>
          new Promise((resolve) => {
            const pickScroller = () => {
              if (selector === "window") return document.scrollingElement || document.documentElement
              if (selector !== "auto") return document.querySelector(selector)
              let best = document.scrollingElement
              let bestOverflow = best ? best.scrollHeight - best.clientHeight : 0
              for (const element of document.querySelectorAll("*")) {
                if (!/(auto|scroll)/.test(getComputedStyle(element).overflowY)) continue
                const overflow = element.scrollHeight - element.clientHeight
                if (overflow > bestOverflow) {
                  best = element
                  bestOverflow = overflow
                }
              }
              return best
            }
            const scroller = pickScroller()
            if (!scroller) return resolve(false)
            const startLeft = scroller.scrollLeft
            const startTop = scroller.scrollTop
            const ease = (t) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2)
            const startedAt = performance.now()
            const frame = (timestamp) => {
              const progress = Math.min(1, (timestamp - startedAt) / durationMs)
              const eased = ease(progress)
              scroller.scrollLeft = startLeft + dx * eased
              scroller.scrollTop = startTop + dy * eased
              if (progress < 1) requestAnimationFrame(frame)
              else resolve(true)
            }
            requestAnimationFrame(frame)
          }),
        { selector, dx, dy, durationMs }
      )
    )
    await this.advance(durationMs + 2 * FRAME_MS)
  }

  /** Captures frames until `predicate` (evaluated in the page) is true or `maxMs` of clip time passes. */
  async advanceUntil(predicate, maxMs, pollEveryFrames = 3) {
    const limit = framesFor(maxMs)
    for (let index = 0; index < limit; index++) {
      await this.frame()
      if (index % pollEveryFrames === 0 && (await this.handle.page.evaluate(predicate).catch(() => false))) return true
    }
    return false
  }

  async stop() {
    logPhase(`${this.name}: stopping after ${this.frameCount} frames`)
    await Promise.all(this.writes)
    this.writes = []
    await Promise.race([Promise.all(this.pending), sleep(3000)])
    await this.handle.cdp.send("Emulation.setVirtualTimePolicy", { policy: "advance" }).catch(() => {})
    this.handle.pump.start()
    logPhase(`${this.name}: stopped`)
  }

  async assemble({ outputWidth, outputHeight, stillName }) {
    logPhase(`${this.name}: encoding`)
    const output = path.join(FOOTAGE_DIR, `${this.name}.mp4`)
    const firstFrame = await readFile(path.join(this.dir, "f_00000.png"))
    const captured = { width: firstFrame.readUInt32BE(16), height: firstFrame.readUInt32BE(20) }
    const needsScale = captured.width !== outputWidth || captured.height !== outputHeight
    const filter = needsScale ? `scale=${outputWidth}:${outputHeight}:flags=lanczos` : "format=yuv420p"
    await execFileAsync(
      "ffmpeg",
      [
        "-y", "-loglevel", "error",
        "-framerate", String(FPS),
        "-i", path.join(this.dir, "f_%05d.png"),
        "-vf", filter,
        "-c:v", "libx264", "-preset", "medium", "-crf", "14",
        "-pix_fmt", "yuv420p", "-r", String(FPS),
        "-movflags", "+faststart",
        output,
      ],
      { maxBuffer: 1 << 24 }
    )
    let still = null
    if (stillName && this.lastFrameFile) {
      still = path.join(STILLS_DIR, `${stillName}.png`)
      await copyFile(this.lastFrameFile, still)
    }
    const { stdout } = await execFileAsync("ffprobe", [
      "-v", "error", "-select_streams", "v:0",
      "-show_entries", "stream=width,height,nb_frames:format=duration",
      "-of", "json", output,
    ])
    const probe = JSON.parse(stdout)
    await rm(this.dir, { recursive: true, force: true })
    logPhase(`${this.name}: encoded ${probe.streams[0].nb_frames} frames`)
    return {
      file: output,
      width: probe.streams[0].width,
      height: probe.streams[0].height,
      frames: Number(probe.streams[0].nb_frames),
      durationSec: Number(probe.format.duration),
      still,
      markers: this.markers,
    }
  }
}

// ---------------------------------------------------------------------------
// Page helpers (run while the pump is on, i.e. between recordings)
// ---------------------------------------------------------------------------
export async function settle(page, { timeoutMs = 15_000, extraMs = 700 } = {}) {
  await page.evaluate(() => document.fonts.ready)
  const deadline = Date.now() + timeoutMs
  while (Date.now() < deadline) {
    const busy = await page.evaluate(() => {
      const visible = (element) => {
        const rect = element.getBoundingClientRect()
        return rect.width > 0 && rect.height > 0 && rect.bottom > 0 && rect.top < innerHeight
      }
      const skeletons = [...document.querySelectorAll(".skel, [data-skeleton], [data-loading], .xt-skeleton, .animate-pulse")].filter(visible)
      const images = [...document.images].filter((img) => visible(img) && img.src && !img.complete)
      return skeletons.length + images.length
    })
    if (busy === 0) break
    await sleep(120)
  }
  await sleep(extraMs)
}

export async function gotoSettled(page, route, options) {
  logPhase(`goto ${route}`)
  await page.goto(`${BASE_URL}${route}`, { waitUntil: "networkidle" })
  logPhase(`loaded ${route}, settling`)
  await settle(page, options)
  logPhase(`settled ${route}`)
}

export async function parkMouse(page) {
  const viewport = page.viewportSize()
  await page.mouse.move(viewport.width - 2, viewport.height - 2)
}

async function centerOf(page, selector) {
  const box = await page.locator(selector).first().boundingBox()
  if (!box) throw new Error(`no box for ${selector}`)
  return { x: box.x + box.width / 2, y: box.y + box.height / 2 }
}

export async function setForceTv(page, enabled) {
  await page.evaluate((enabled) => {
    if (enabled) localStorage.setItem("xt_force_tv", "1")
    else localStorage.removeItem("xt_force_tv")
  }, enabled)
}

/** TV Live opens on Favorites (3 rows); "All channels" gives the D-pad 40 rows to walk. */
export async function selectAllChannelsGroup(page) {
  await page.evaluate(() => {
    const buttons = [...document.querySelectorAll("[data-group-key]")]
    const target = buttons.find((button) => /all channels/i.test(button.textContent || "")) || buttons[1]
    target?.focus()
  })
  await page.keyboard.press("Enter")
  await sleep(1200)
  await page.evaluate(() => document.querySelector("[data-channel-key]")?.focus())
  await sleep(400)
}

export async function warmContext(page) {
  await gotoSettled(page, "/livetv", { extraMs: 300 })
  await page.waitForSelector(".channel-row:not([data-skeleton])", { timeout: 20_000 })
  await gotoSettled(page, "/movies", { extraMs: 300 })
  await gotoSettled(page, "/series", { extraMs: 300 })
  await gotoSettled(page, "/epg", { extraMs: 300 })
  await page.waitForSelector("#epg-grid:not(.hidden)", { timeout: 20_000 })
}

export async function waitForStableCount(page, selector, { minCount = 1, timeoutMs = 20_000 } = {}) {
  await page.waitForSelector(selector, { timeout: timeoutMs })
  const deadline = Date.now() + timeoutMs
  let previous = -1
  while (Date.now() < deadline) {
    const count = await page.locator(selector).count()
    if (count >= minCount && count === previous) return count
    previous = count
    await sleep(400)
  }
  return previous
}

// ---------------------------------------------------------------------------
// Clips
// ---------------------------------------------------------------------------
const DESKTOP_OUTPUT = { outputWidth: 1920, outputHeight: 1080 }
const PHONE_OUTPUT = { outputWidth: 1236, outputHeight: 2744 }

const desktopClips = {
  async splash(context) {
    const setup = await openPage(context)
    await setup.page.goto(`${BASE_URL}/login`, { waitUntil: "domcontentloaded" })
    await setup.page.evaluate(() => localStorage.setItem("xt_demo_show_splash", "1"))
    await closePage(setup)

    const handle = await openPage(context)
    await handle.page.setContent('<body style="margin:0;background:#0b1020"></body>')
    await parkMouse(handle.page)
    const recorder = new Recorder(handle, "splash")
    await recorder.start()
    await recorder.advance(200)
    recorder.mark("navigation starts")
    recorder.act(() => handle.page.goto(`${BASE_URL}/`, { waitUntil: "commit" }))
    await recorder.advanceUntil(() => !!document.getElementById("xt-app-splash"), 3000)
    recorder.mark("splash visible")
    await recorder.advanceUntil(() => !document.getElementById("xt-app-splash"), 9000)
    recorder.mark("splash removed, hub revealed")
    await recorder.advance(1600)
    await recorder.stop()
    await handle.page.evaluate(() => localStorage.removeItem("xt_demo_show_splash"))
    const result = await recorder.assemble({ ...DESKTOP_OUTPUT, stillName: null })
    await closePage(handle)
    return { ...result, notes: "Fresh load of / with no xt_splash_done: nebula backdrop fades in, the infinity mark draws itself, the comet orbits the figure-8, the wordmark appears, then the splash fades (600 ms) into the populated hub." }
  },

  async hub(context) {
    const handle = await openPage(context)
    await handle.page.setContent('<body style="margin:0;background:#0b1020"></body>')
    await parkMouse(handle.page)
    const recorder = new Recorder(handle, "hub")
    await recorder.start()
    await recorder.advance(150)
    recorder.mark("navigation starts")
    recorder.act(() => handle.page.goto(`${BASE_URL}/`, { waitUntil: "commit" }))
    await recorder.advanceUntil(() => document.querySelectorAll("#hub-tiles a").length === 3 && document.querySelectorAll("main img").length > 4, 4000)
    recorder.mark("hub painted; tiles stagger in over the next 0.6 s, strips fill")
    await recorder.advance(1500)
    const liveTile = await centerOf(handle.page, '#hub-tiles a[href="/livetv"]')
    const moviesTile = await centerOf(handle.page, '#hub-tiles a[href="/movies"]')
    const seriesTile = await centerOf(handle.page, '#hub-tiles a[href="/series"]')
    recorder.mark("pointer glides to Live TV tile")
    await recorder.glideMouse({ x: DESKTOP_VIEWPORT.width - 2, y: DESKTOP_VIEWPORT.height - 2 }, liveTile, 1100)
    await recorder.advance(700)
    recorder.mark("pointer glides to Movies tile")
    await recorder.glideMouse(liveTile, moviesTile, 900)
    await recorder.advance(700)
    recorder.mark("pointer glides to Series tile")
    await recorder.glideMouse(moviesTile, seriesTile, 900)
    await recorder.advance(1000)
    await recorder.stop()
    const result = await recorder.assemble({ ...DESKTOP_OUTPUT, stillName: null })
    await closePage(handle)
    return { ...result, notes: "Hub loads from a dark frame: marquee, the three tiles stagger in, favourites / continue-watching strips fill. Then the pointer (not drawn in headless capture) glides Live TV -> Movies -> Series; each tile lifts and its border and heading take the accent colour." }
  },

  async livetv(context) {
    const handle = await openPage(context)
    await parkMouse(handle.page)
    await gotoSettled(handle.page, "/livetv", { extraMs: 400 })
    await handle.page.waitForSelector(".channel-row:not([data-skeleton])", { timeout: 20_000 })
    await settle(handle.page, { extraMs: 800 })
    const recorder = new Recorder(handle, "livetv", { networkPolicy: "advance" })
    await recorder.start()
    await recorder.advance(900)
    recorder.mark("focus lands on first channel")
    recorder.act(() => handle.page.evaluate(() => document.querySelector('#viewport [data-idx="0"] .play-btn')?.focus()))
    await recorder.advance(700)
    recorder.mark("ArrowDown x4 begins")
    await recorder.pressSlowly(["ArrowDown", "ArrowDown", "ArrowDown", "ArrowDown"], 600)
    recorder.mark("Enter tunes channel 5")
    recorder.press("Enter")
    const failed = await recorder.advanceUntil(() => !!document.querySelector("[data-playback-failure], .xt-toast"), 3200, 2)
    if (failed) recorder.mark("playback failure surfaced (trim here)")
    await recorder.stop()
    const result = await recorder.assemble({ ...DESKTOP_OUTPUT, stillName: null })
    await closePage(handle)
    return {
      ...result,
      trimHint: failed ? "Cut the last ~0.2 s: the playback-failure panel appears at the very end (the fixture has no real stream)." : null,
      notes: "Channel list with logos, channel numbers, now-playing titles and progress bars. Focus steps down 4 rows (600 ms apart), Enter tunes the 5th channel: the player leaves the idle state and the programme panel below fills with now/next.",
    }
  },

  async epg(context) {
    const handle = await openPage(context)
    await parkMouse(handle.page)
    await gotoSettled(handle.page, "/epg", { extraMs: 400 })
    await handle.page.waitForSelector("#epg-grid:not(.hidden)", { timeout: 20_000 })
    await settle(handle.page, { extraMs: 900 })
    const overflow = await handle.page.evaluate(() => {
      const grid = document.getElementById("epg-grid")
      return { x: grid.scrollWidth - grid.clientWidth, y: grid.scrollHeight - grid.clientHeight }
    })
    const recorder = new Recorder(handle, "epg")
    await recorder.start()
    await recorder.advance(800)
    let motion
    if (overflow.x > 120) {
      recorder.mark("horizontal drift starts")
      await recorder.smoothScroll("#epg-grid", { dx: Math.min(overflow.x, 420), durationMs: 4000 })
      motion = `eased horizontal drift of ${Math.min(overflow.x, 420)} px over 4 s`
    } else {
      recorder.mark("vertical drift starts")
      await recorder.smoothScroll("#epg-grid", { dy: Math.min(overflow.y, 560), durationMs: 4000 })
      motion = `eased vertical drift of ${Math.min(overflow.y, 560)} px over 4 s (the 6-hour grid fits inside the 1920 px viewport, so there is no horizontal overflow to scroll)`
    }
    recorder.mark("drift ends")
    await recorder.advance(1000)
    await recorder.stop()
    const result = await recorder.assemble({ ...DESKTOP_OUTPUT, stillName: null })
    await closePage(handle)
    return { ...result, notes: `Programme guide: channel column with logos, half-hour time header, now-line, current programmes highlighted. ${motion}.` }
  },

  async "tv-home"(context) {
    const handle = await openPage(context)
    await parkMouse(handle.page)
    await handle.page.goto(`${BASE_URL}/login`, { waitUntil: "domcontentloaded" })
    await setForceTv(handle.page, true)
    await handle.page.goto(`${BASE_URL}/tv`, { waitUntil: "networkidle" })
    await waitForStableCount(handle.page, "[data-tv-view-root] [data-focus-key]", { minCount: 4 })
    await settle(handle.page, { extraMs: 900 })
    // Default focus sits on the nav rail; one ArrowRight lands on the hero before recording starts.
    await handle.page.keyboard.press("ArrowRight")
    await sleep(900)
    const recorder = new Recorder(handle, "tv-home")
    await recorder.start()
    await recorder.advance(900)
    recorder.mark("ArrowDown: hero -> first Favorites card")
    await recorder.pressSlowly(["ArrowDown"], 900)
    recorder.mark("ArrowRight x3 across the rail")
    await recorder.pressSlowly(["ArrowRight", "ArrowRight", "ArrowRight"], 700)
    recorder.mark("ArrowDown: Continue watching rail")
    await recorder.pressSlowly(["ArrowDown"], 900)
    recorder.mark("ArrowRight x2")
    await recorder.pressSlowly(["ArrowRight", "ArrowRight"], 700)
    await recorder.advance(900)
    await recorder.stop()
    const result = await recorder.assemble({ ...DESKTOP_OUTPUT, stillName: null })
    await setForceTv(handle.page, false)
    await closePage(handle)
    return { ...result, notes: "TV home (/tv): hero focused at start. ArrowDown drops the glide ring onto the first Favorites card, ArrowRight x3 (700 ms apart) slides across to the first movie poster while the hero crossfades per card, ArrowDown scrolls to the Continue watching rail, ArrowRight x2." }
  },

  async "tv-live"(context) {
    const handle = await openPage(context)
    await parkMouse(handle.page)
    await handle.page.goto(`${BASE_URL}/login`, { waitUntil: "domcontentloaded" })
    await setForceTv(handle.page, true)
    await handle.page.goto(`${BASE_URL}/tv/live`, { waitUntil: "networkidle" })
    await waitForStableCount(handle.page, "[data-channel-key]", { minCount: 3 })
    await sleep(2500)
    await selectAllChannelsGroup(handle.page)
    // The guide panel's first paint predates the EPG load; re-focusing the row refreshes it.
    await handle.page.keyboard.press("ArrowDown")
    await sleep(500)
    await handle.page.keyboard.press("ArrowUp")
    await settle(handle.page, { extraMs: 1000 })
    const recorder = new Recorder(handle, "tv-live")
    await recorder.start()
    await recorder.advance(1000)
    recorder.mark("ArrowDown x5 begins")
    await recorder.pressSlowly(["ArrowDown", "ArrowDown", "ArrowDown", "ArrowDown", "ArrowDown"], 700)
    await recorder.advance(1000)
    await recorder.stop()
    const result = await recorder.assemble({ ...DESKTOP_OUTPUT, stillName: null })
    await setForceTv(handle.page, false)
    await closePage(handle)
    return { ...result, notes: "TV Live (/tv/live) on the All channels group: category column, channel rows with logo, now/next and progress, programme guide panel on the right. Focus steps down 5 channels (700 ms apart); the guide panel crossfades to each focused channel with its current programme and Up next list." }
  },

  async search(context) {
    const handle = await openPage(context)
    await parkMouse(handle.page)
    await gotoSettled(handle.page, "/search", { extraMs: 600 })
    const input = handle.page.locator('main input[type="search"]').first()
    await input.waitFor({ timeout: 15_000 })
    await input.focus()
    await sleep(300)
    const recorder = new Recorder(handle, "search")
    await recorder.start()
    await recorder.advance(800)
    recorder.mark('typing "north" begins')
    await recorder.typeSlowly("north", 120)
    recorder.mark("results settle")
    await recorder.advance(2800)
    await recorder.stop()
    const result = await recorder.assemble({ ...DESKTOP_OUTPUT, stillName: null })
    await closePage(handle)
    return { ...result, notes: 'Search page with the input focused; "north" is typed one character per 120 ms and results narrow live to Northwind News plus the Northern Lights Express movie.' }
  },
}

const phoneClips = {
  async "phone-hub"(context) {
    const handle = await openPage(context)
    await gotoSettled(handle.page, "/", { extraMs: 1200 })
    const recorder = new Recorder(handle, "phone-hub")
    await recorder.start()
    await recorder.advance(900)
    recorder.mark("scroll starts")
    await recorder.smoothScroll("auto", { dy: 900, durationMs: 4200 })
    recorder.mark("scroll ends")
    await recorder.advance(900)
    await recorder.stop()
    const result = await recorder.assemble({ ...PHONE_OUTPUT, stillName: "phone-hub-end" })
    await closePage(handle)
    return { ...result, notes: "Phone hub (412x915 CSS px @3x, portrait): marquee, tiles and strips; slow eased scroll down 900 px over 4.2 s." }
  },

  async "phone-livetv"(context) {
    const handle = await openPage(context)
    await gotoSettled(handle.page, "/livetv", { extraMs: 600 })
    await handle.page.waitForSelector(".channel-row:not([data-skeleton])", { timeout: 20_000 })
    await settle(handle.page, { extraMs: 900 })
    // Warm every logo the drift will pass, then park the list one overscan block down.
    for (const top of [56 * 6, 56 * 12, 56 * 16, 56 * 6]) {
      await handle.page.evaluate((value) => { document.getElementById("list").scrollTop = value }, top)
      await sleep(1500)
    }
    await settle(handle.page, { extraMs: 900 })
    // The list rebuilds every row on each scroll tick; under frame-stepped capture that leaves
    // freshly created <img>s unpainted on every frame. Pin the rendered window for the drift and
    // keep the distance inside it (overscan is 6 rows either side).
    const driftRows = await handle.page.evaluate(() => {
      const list = document.getElementById("list")
      const rendered = document.querySelectorAll("#viewport .channel-row").length
      const visibleRows = Math.ceil(list.clientHeight / 56)
      window.__xtFreezeRows = true
      list.addEventListener("scroll", (event) => { if (window.__xtFreezeRows) event.stopImmediatePropagation() }, { capture: true })
      return Math.max(3, Math.min(8, rendered - visibleRows - 7))
    })
    const recorder = new Recorder(handle, "phone-livetv")
    await recorder.start()
    await recorder.advance(900)
    recorder.mark("scroll starts")
    await recorder.smoothScroll("#list", { dy: 56 * driftRows, durationMs: 4200 })
    recorder.mark("scroll ends")
    await recorder.advance(900)
    await recorder.stop()
    await handle.page.evaluate(() => { window.__xtFreezeRows = false })
    const result = await recorder.assemble({ ...PHONE_OUTPUT, stillName: "phone-livetv-end" })
    await closePage(handle)
    return { ...result, notes: `Phone Live TV (412x915 CSS px @3x, portrait): idle player card on top, channel list with logos, numbers and now-playing progress below; slow eased scroll of ${driftRows} rows (${56 * driftRows} px) over 4.2 s.` }
  },
}

// ---------------------------------------------------------------------------
// 2x still pass: reproduce each desktop clip's end state quickly, shoot one frame
// ---------------------------------------------------------------------------
async function shootStill(handle, stillName) {
  const file = path.join(STILLS_DIR, `${stillName}.png`)
  await handle.page.screenshot({ path: file, type: "png", animations: "allow", caret: "hide" })
  return file
}

async function pressSequence(page, keys, gapMs) {
  for (const key of keys) {
    await page.keyboard.press(key)
    await sleep(gapMs)
  }
}

const stillScenes = {
  async splash(handle) {
    await gotoSettled(handle.page, "/", { extraMs: 1500 })
    return shootStill(handle, "splash-end")
  },
  async hub(handle) {
    await gotoSettled(handle.page, "/", { extraMs: 1500 })
    const seriesTile = await centerOf(handle.page, '#hub-tiles a[href="/series"]')
    await handle.page.mouse.move(seriesTile.x, seriesTile.y)
    await sleep(900)
    return shootStill(handle, "hub-end")
  },
  async livetv(handle) {
    await gotoSettled(handle.page, "/livetv", { extraMs: 400 })
    await handle.page.waitForSelector(".channel-row:not([data-skeleton])", { timeout: 20_000 })
    await settle(handle.page, { extraMs: 800 })
    await handle.page.evaluate(() => document.querySelector('#viewport [data-idx="0"] .play-btn')?.focus())
    await pressSequence(handle.page, ["ArrowDown", "ArrowDown", "ArrowDown", "ArrowDown"], 250)
    await handle.page.keyboard.press("Enter")
    await sleep(1500)
    return shootStill(handle, "livetv-end")
  },
  async epg(handle) {
    await gotoSettled(handle.page, "/epg", { extraMs: 400 })
    await handle.page.waitForSelector("#epg-grid:not(.hidden)", { timeout: 20_000 })
    await settle(handle.page, { extraMs: 900 })
    await handle.page.evaluate(() => {
      const grid = document.getElementById("epg-grid")
      const overflowX = grid.scrollWidth - grid.clientWidth
      if (overflowX > 120) grid.scrollLeft += Math.min(overflowX, 420)
      else grid.scrollTop += Math.min(grid.scrollHeight - grid.clientHeight, 560)
    })
    await sleep(800)
    return shootStill(handle, "epg-end")
  },
  async "tv-home"(handle) {
    await handle.page.goto(`${BASE_URL}/login`, { waitUntil: "domcontentloaded" })
    await setForceTv(handle.page, true)
    await handle.page.goto(`${BASE_URL}/tv`, { waitUntil: "networkidle" })
    await waitForStableCount(handle.page, "[data-tv-view-root] [data-focus-key]", { minCount: 4 })
    await settle(handle.page, { extraMs: 900 })
    await pressSequence(handle.page, ["ArrowRight", "ArrowDown", "ArrowRight", "ArrowRight", "ArrowRight", "ArrowDown", "ArrowRight", "ArrowRight"], 450)
    await settle(handle.page, { extraMs: 1200 })
    const file = await shootStill(handle, "tv-home-end")
    await setForceTv(handle.page, false)
    return file
  },
  async "tv-live"(handle) {
    await handle.page.goto(`${BASE_URL}/login`, { waitUntil: "domcontentloaded" })
    await setForceTv(handle.page, true)
    await handle.page.goto(`${BASE_URL}/tv/live`, { waitUntil: "networkidle" })
    await waitForStableCount(handle.page, "[data-channel-key]", { minCount: 3 })
    await sleep(2500)
    await selectAllChannelsGroup(handle.page)
    await pressSequence(handle.page, ["ArrowDown", "ArrowDown", "ArrowDown", "ArrowDown", "ArrowDown"], 450)
    await settle(handle.page, { extraMs: 1200 })
    const file = await shootStill(handle, "tv-live-end")
    await setForceTv(handle.page, false)
    return file
  },
  async search(handle) {
    await gotoSettled(handle.page, "/search", { extraMs: 600 })
    const input = handle.page.locator('main input[type="search"]').first()
    await input.waitFor({ timeout: 15_000 })
    await input.focus()
    await input.pressSequentially("north", { delay: 80 })
    await settle(handle.page, { extraMs: 1500 })
    return shootStill(handle, "search-end")
  },
}

// ---------------------------------------------------------------------------
// Main
// ---------------------------------------------------------------------------
async function runClipSet({ pngByPath, launchArgs, contextOptions, clips, wanted }) {
  const selected = Object.entries(clips).filter(([name]) => !wanted.length || wanted.includes(name))
  for (const [name, clip] of selected) {
    console.log(`recording ${name}`)
    const started = Date.now()
    const { browser, context } = await openWarmContext({ pngByPath, launchArgs, contextOptions })
    try {
      const result = await clip(context)
      clipNotes.push({ name, ...result, wallSec: Math.round((Date.now() - started) / 1000) })
      console.log(`  ${result.file} ${result.width}x${result.height} ${result.durationSec.toFixed(2)}s (${Math.round((Date.now() - started) / 1000)}s wall)`)
      await persistRun()
    } finally {
      await closeBrowser(browser, context)
    }
  }
}

/** Stills render in regular headless Chromium at 2x (real-time clock): plain page.screenshot, no BeginFrame control. */
async function runStillPass({ pngByPath, contextOptions, wanted }) {
  const selected = Object.entries(stillScenes).filter(([name]) => !wanted.length || wanted.includes(name))
  for (const [name, scene] of selected) {
    for (let attempt = 0; attempt < 2 && !stillFiles[name]; attempt++) {
      logPhase(`still ${name}${attempt ? " (retry)" : ""}`)
      const browser = await chromium.launch({ executablePath: CHROMIUM_PATH, headless: true, args: ["--force-color-profile=srgb", "--autoplay-policy=no-user-gesture-required"] })
      try {
        const context = await browser.newContext(contextOptions)
        await installRoutes(context, pngByPath)
        await seedContext(context)
        const warmPage = await context.newPage()
        await warmContext(warmPage)
        await warmPage.close()
        const page = await context.newPage()
        await parkMouse(page)
        const file = await scene({ page })
        await page.close()
        stillFiles[name] = file
        logPhase(`  -> ${file}`)
        await persistRun()
      } catch (error) {
        logPhase(`still ${name} failed: ${error.message}`)
      } finally {
        await closeBrowser(browser)
      }
    }
  }
}

async function persistRun() {
  const merged = new Map((await readPreviousRun()).map((clip) => [clip.name, clip]))
  for (const clip of clipNotes) merged.set(clip.name, clip)
  for (const [name, file] of Object.entries(stillFiles)) {
    const clip = merged.get(name)
    if (clip) clip.still = file
  }
  await writeFile(path.join(ASSETS_DIR, "last-run.json"), JSON.stringify({ recordedAt: new Date().toISOString(), clips: [...merged.values()] }, null, 2))
}

async function readPreviousRun() {
  try {
    const parsed = JSON.parse(await readFile(path.join(ASSETS_DIR, "last-run.json"), "utf8"))
    return Array.isArray(parsed.clips) ? parsed.clips : []
  } catch {
    return []
  }
}

async function main() {
  const stillsOnly = process.argv.includes("--stills-only")
  const wanted = process.argv.slice(2).filter((argument) => !argument.startsWith("--"))
  for (const signal of ["SIGTERM", "SIGINT", "SIGHUP"]) process.on(signal, () => { logPhase(`received ${signal}`); process.exit(1) })
  process.on("exit", (code) => logPhase(`process exit ${code}`))
  process.on("uncaughtException", (error) => { logPhase(`uncaught: ${error.stack || error}`); process.exit(1) })
  process.on("unhandledRejection", (error) => { logPhase(`unhandled rejection: ${error?.stack || error}`); process.exit(1) })
  await mkdir(FOOTAGE_DIR, { recursive: true })
  await mkdir(STILLS_DIR, { recursive: true })
  await mkdir(FRAMES_ROOT, { recursive: true })
  const artBrowser = await chromium.launch({ executablePath: CHROMIUM_PATH, headless: true })
  const pngByPath = await rasterizeArtwork(artBrowser)
  await artBrowser.close()
  console.log(`rasterised ${pngByPath.size} artwork files`)

  if (!stillsOnly) await runClipSet({
    pngByPath,
    launchArgs: [`--window-size=${DESKTOP_VIEWPORT.width},${DESKTOP_VIEWPORT.height}`],
    contextOptions: { viewport: DESKTOP_VIEWPORT, deviceScaleFactor: 1, colorScheme: "dark", locale: "en-US", timezoneId: TIMEZONE },
    clips: desktopClips,
    wanted,
  })
  if (!wanted.length || wanted.some((name) => name in desktopClips)) {
    await runStillPass({
      pngByPath,
      contextOptions: { viewport: DESKTOP_VIEWPORT, deviceScaleFactor: 2, colorScheme: "dark", locale: "en-US", timezoneId: TIMEZONE },
      wanted,
    })
  }
  if (!stillsOnly) await runClipSet({
    pngByPath,
    launchArgs: ["--force-device-scale-factor=3", `--window-size=${PHONE_VIEWPORT.width},${PHONE_VIEWPORT.height}`],
    contextOptions: {
      viewport: PHONE_VIEWPORT,
      deviceScaleFactor: 3,
      isMobile: true,
      hasTouch: true,
      colorScheme: "dark",
      locale: "en-US",
      timezoneId: TIMEZONE,
      userAgent:
        "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36",
    },
    clips: phoneClips,
    wanted,
  })

  await persistRun()
  console.log(JSON.stringify(clipNotes, null, 2))
}

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  main().catch((error) => {
    console.error(error)
    process.exit(1)
  })
}
