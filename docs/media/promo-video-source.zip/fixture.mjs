// Fictional Xtream provider fixture: channels, VOD, series, artwork SVGs, XMLTV and player_api.php answers.

export const FIXTURE_HOST = "https://fixtures.invalid"
export const FIXTURE_USER = "demo"
export const FIXTURE_PASS = "demo"
export const PLAYLIST_ID = "demo-playlist"
export const PLAYLIST_TITLE = "Northwind IPTV"

const GROUP_PALETTES = {
  News: [
    ["#3b4a6b", "#5b7fa6"],
    ["#2d4a5e", "#4a7d95"],
    ["#44405c", "#6b6390"],
  ],
  Sports: [
    ["#2f5d62", "#4f8a8b"],
    ["#3a5a40", "#6a8f6b"],
    ["#2d4a5e", "#4a7d95"],
  ],
  Movies: [
    ["#5c3f45", "#8a6068"],
    ["#44405c", "#6b6390"],
    ["#3b3f4d", "#5f6675"],
  ],
  Kids: [
    ["#7a5c2e", "#b08a4a"],
    ["#3a5a40", "#6a8f6b"],
    ["#2f5d62", "#4f8a8b"],
  ],
  Documentary: [
    ["#5a4f3b", "#8c7a5b"],
    ["#2f5d62", "#4f8a8b"],
    ["#3b4a6b", "#5b7fa6"],
  ],
  Music: [
    ["#44405c", "#6b6390"],
    ["#5c3f45", "#8a6068"],
    ["#3b4a6b", "#5b7fa6"],
  ],
}

const CHANNEL_DEFS = [
  ["News", 101, "Northwind News"],
  ["News", 102, "Meridian 24"],
  ["News", 103, "Capital Report"],
  ["News", 104, "Harbor News"],
  ["News", 105, "Global Ledger"],
  ["News", 106, "Summit Business"],
  ["News", 107, "Weather Compass"],
  ["Sports", 201, "Arena Sports 1"],
  ["Sports", 202, "Arena Sports 2"],
  ["Sports", 203, "Arena Sports 3"],
  ["Sports", 204, "Pitchside"],
  ["Sports", 205, "Motorline"],
  ["Sports", 206, "Court & Ring"],
  ["Sports", 207, "Peak Outdoors"],
  ["Sports", 208, "Tidewater Golf"],
  ["Movies", 301, "Cinema One"],
  ["Movies", 302, "Cinema Classics"],
  ["Movies", 303, "Cinema Noir"],
  ["Movies", 304, "Lantern Films"],
  ["Movies", 305, "Midnight Reel"],
  ["Movies", 306, "Studio Silver"],
  ["Movies", 307, "Comet Action"],
  ["Kids", 401, "Little Lantern"],
  ["Kids", 402, "Pip & Pals"],
  ["Kids", 403, "Skyward Kids"],
  ["Kids", 404, "Storybook TV"],
  ["Kids", 405, "Junior Quest"],
  ["Kids", 406, "Bumble Tunes"],
  ["Documentary", 501, "Atlas Documentary"],
  ["Documentary", 502, "Deep Field"],
  ["Documentary", 503, "Terra Wild"],
  ["Documentary", 504, "Chronicle"],
  ["Documentary", 505, "Blue Horizon"],
  ["Documentary", 506, "Workshop"],
  ["Music", 601, "Pulse Music"],
  ["Music", 602, "Velvet Jazz"],
  ["Music", 603, "Cadence Classical"],
  ["Music", 604, "Roots & Folk"],
  ["Music", 605, "Late Night Lounge"],
  ["Music", 606, "Aurora Hits"],
]

export const LIVE_GROUPS = ["News", "Sports", "Movies", "Kids", "Documentary", "Music"]

export function slugify(name) {
  return name
    .toLowerCase()
    .replace(/&/g, "and")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
}

function initialsFor(name) {
  const words = name.replace(/&/g, "").split(/\s+/).filter(Boolean)
  if (words.length === 1) return words[0].slice(0, 2).toUpperCase()
  const letters = words.map((word) => (/^\d+$/.test(word) ? word : word[0]))
  return letters.slice(0, 3).join("").toUpperCase()
}

export const CHANNELS = CHANNEL_DEFS.map(([group, chno, name], index) => {
  const slug = slugify(name)
  const palette = GROUP_PALETTES[group][index % GROUP_PALETTES[group].length]
  return {
    id: chno,
    chno,
    name,
    group,
    slug,
    tvgId: `${slug}.demo`,
    initials: initialsFor(name),
    palette,
    logoUrl: `${FIXTURE_HOST}/logos/${slug}.png`,
  }
})

// ---------------------------------------------------------------------------
// Artwork
// ---------------------------------------------------------------------------
function escapeXml(text) {
  return String(text)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
}

export function logoSvg(channel) {
  const [from, to] = channel.palette
  const fontSize = channel.initials.length >= 3 ? 150 : 190
  return `<svg xmlns="http://www.w3.org/2000/svg" width="512" height="512" viewBox="0 0 512 512">
  <defs>
    <linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0" stop-color="${from}"/>
      <stop offset="1" stop-color="${to}"/>
    </linearGradient>
  </defs>
  <rect x="16" y="16" width="480" height="480" rx="96" fill="url(#g)"/>
  <rect x="16" y="16" width="480" height="480" rx="96" fill="none" stroke="rgba(255,255,255,0.14)" stroke-width="6"/>
  <text x="256" y="256" text-anchor="middle" dominant-baseline="central" font-family="Geist Variable, Inter, Helvetica, Arial, sans-serif" font-weight="700" font-size="${fontSize}" fill="#ffffff" letter-spacing="-6">${escapeXml(channel.initials)}</text>
</svg>`
}

const POSTER_PALETTES = [
  ["#1f2a44", "#3d5a80"],
  ["#2b3a3f", "#4f7c82"],
  ["#3d2f3a", "#7a5c6c"],
  ["#2c3e2f", "#5c8a5a"],
  ["#40341f", "#8a6f3a"],
  ["#262b3a", "#5a6b8c"],
  ["#3a2d2d", "#8a5a4a"],
  ["#1f3a3a", "#3f7a72"],
]

function wrapTitle(title, maxChars) {
  const words = title.split(" ")
  const lines = []
  let current = ""
  for (const word of words) {
    const candidate = current ? `${current} ${word}` : word
    if (candidate.length > maxChars && current) {
      lines.push(current)
      current = word
    } else {
      current = candidate
    }
  }
  if (current) lines.push(current)
  return lines
}

export function posterSvg(title, meta, paletteIndex) {
  const [from, to] = POSTER_PALETTES[paletteIndex % POSTER_PALETTES.length]
  const lines = wrapTitle(title.toUpperCase(), 11)
  const lineHeight = 58
  const startY = 560 - (lines.length - 1) * lineHeight
  const textLines = lines
    .map((line, index) => `<text x="40" y="${startY + index * lineHeight}" font-family="Geist Variable, Inter, Helvetica, Arial, sans-serif" font-weight="700" font-size="54" fill="#ffffff" letter-spacing="-1.5">${escapeXml(line)}</text>`)
    .join("\n")
  return `<svg xmlns="http://www.w3.org/2000/svg" width="480" height="720" viewBox="0 0 480 720">
  <defs>
    <linearGradient id="g" x1="0" y1="0" x2="0.6" y2="1">
      <stop offset="0" stop-color="${to}"/>
      <stop offset="1" stop-color="${from}"/>
    </linearGradient>
    <radialGradient id="glow" cx="0.75" cy="0.2" r="0.7">
      <stop offset="0" stop-color="rgba(255,255,255,0.22)"/>
      <stop offset="1" stop-color="rgba(255,255,255,0)"/>
    </radialGradient>
    <linearGradient id="shade" x1="0" y1="0.4" x2="0" y2="1">
      <stop offset="0" stop-color="rgba(0,0,0,0)"/>
      <stop offset="1" stop-color="rgba(0,0,0,0.55)"/>
    </linearGradient>
  </defs>
  <rect width="480" height="720" fill="url(#g)"/>
  <rect width="480" height="720" fill="url(#glow)"/>
  <circle cx="360" cy="230" r="150" fill="none" stroke="rgba(255,255,255,0.10)" stroke-width="28"/>
  <circle cx="120" cy="150" r="70" fill="rgba(255,255,255,0.06)"/>
  <rect width="480" height="720" fill="url(#shade)"/>
  ${textLines}
  <text x="40" y="640" font-family="Geist Variable, Inter, Helvetica, Arial, sans-serif" font-weight="500" font-size="24" fill="rgba(255,255,255,0.72)" letter-spacing="2">${escapeXml(meta)}</text>
</svg>`
}

export function backdropSvg(title, paletteIndex) {
  const [from, to] = POSTER_PALETTES[paletteIndex % POSTER_PALETTES.length]
  return `<svg xmlns="http://www.w3.org/2000/svg" width="1280" height="720" viewBox="0 0 1280 720">
  <defs>
    <linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0" stop-color="${from}"/>
      <stop offset="1" stop-color="${to}"/>
    </linearGradient>
    <radialGradient id="glow" cx="0.8" cy="0.3" r="0.7">
      <stop offset="0" stop-color="rgba(255,255,255,0.30)"/>
      <stop offset="1" stop-color="rgba(255,255,255,0)"/>
    </radialGradient>
  </defs>
  <rect width="1280" height="720" fill="url(#g)"/>
  <rect width="1280" height="720" fill="url(#glow)"/>
  <circle cx="980" cy="260" r="260" fill="none" stroke="rgba(255,255,255,0.08)" stroke-width="60"/>
  <circle cx="220" cy="560" r="180" fill="rgba(0,0,0,0.12)"/>
  <text x="80" y="620" font-family="Geist Variable, Inter, Helvetica, Arial, sans-serif" font-weight="700" font-size="84" fill="rgba(255,255,255,0.92)" letter-spacing="-2">${escapeXml(title.toUpperCase())}</text>
</svg>`
}

// ---------------------------------------------------------------------------
// VOD + series
// ---------------------------------------------------------------------------
const MOVIE_DEFS = [
  ["The Salt Road", 2024, "Drama", "8.1", 128],
  ["Paper Lanterns", 2023, "Drama", "7.6", 112],
  ["Northern Lights Express", 2025, "Adventure", "7.9", 121],
  ["The Quiet Harbor", 2022, "Drama", "7.4", 104],
  ["Glass Orchard", 2024, "Thriller", "7.8", 117],
  ["Last Ferry Home", 2021, "Drama", "7.2", 99],
  ["Ember Coast", 2025, "Thriller", "8.3", 131],
  ["Signal Hill", 2023, "Sci-Fi", "7.7", 124],
  ["Winter Cartographer", 2024, "Adventure", "8.0", 138],
  ["Blue Meridian", 2022, "Sci-Fi", "7.5", 109],
  ["The Understudy", 2023, "Comedy", "7.1", 96],
  ["Hollow Frequency", 2025, "Thriller", "7.9", 115],
  ["Copper Sky", 2021, "Adventure", "6.9", 102],
  ["A Table for Nine", 2024, "Comedy", "7.3", 98],
  ["Stillwater Run", 2022, "Thriller", "7.6", 111],
  ["Orbit of Small Things", 2025, "Sci-Fi", "8.2", 127],
  ["Marginalia", 2023, "Drama", "7.0", 93],
  ["The Lantern Keeper", 2024, "Adventure", "7.8", 119],
  ["Half Past Nowhere", 2022, "Comedy", "6.8", 101],
  ["Tidewater", 2025, "Drama", "8.4", 134],
  ["Second Light", 2023, "Sci-Fi", "7.4", 108],
  ["The Long Evening", 2024, "Drama", "7.7", 116],
  ["Cold Open", 2021, "Thriller", "7.2", 105],
  ["Garden of Static", 2025, "Sci-Fi", "7.9", 122],
]

const MOVIE_CATEGORIES = ["Drama", "Thriller", "Sci-Fi", "Adventure", "Comedy"]

export const MOVIES = MOVIE_DEFS.map(([name, year, category, rating, runtime], index) => {
  const slug = slugify(name)
  return {
    id: 1001 + index,
    name,
    year,
    category,
    categoryId: 10 + MOVIE_CATEGORIES.indexOf(category),
    rating,
    runtime,
    slug,
    paletteIndex: index,
    posterUrl: `${FIXTURE_HOST}/posters/${slug}.png`,
    backdropUrl: `${FIXTURE_HOST}/backdrops/${slug}.png`,
    plot: `A quietly told story that follows its characters through one turning season, shot on location and scored for a room with the lights down.`,
  }
})

const SERIES_DEFS = [
  ["Harbor Lights", 2023, "Drama", "8.5", 3],
  ["The Cartographers", 2024, "Mystery", "8.2", 2],
  ["Night Desk", 2022, "Thriller", "7.9", 4],
  ["Saltmarsh", 2025, "Drama", "8.7", 1],
  ["Field Notes", 2021, "Documentary", "8.0", 5],
  ["Second Summer", 2024, "Comedy", "7.6", 2],
  ["The Understory", 2023, "Documentary", "8.3", 2],
  ["Meridian House", 2025, "Drama", "8.1", 1],
  ["Low Tide", 2022, "Mystery", "7.8", 3],
  ["Signal & Noise", 2024, "Sci-Fi", "8.0", 2],
  ["Parish", 2023, "Thriller", "7.7", 3],
  ["The Long Table", 2025, "Comedy", "7.5", 1],
]

const SERIES_CATEGORIES = ["Drama", "Mystery", "Thriller", "Documentary", "Comedy", "Sci-Fi"]

export const SERIES = SERIES_DEFS.map(([name, year, category, rating, seasons], index) => {
  const slug = slugify(name)
  return {
    id: 2001 + index,
    name,
    year,
    category,
    categoryId: 20 + SERIES_CATEGORIES.indexOf(category),
    rating,
    seasons,
    slug,
    paletteIndex: index + 3,
    posterUrl: `${FIXTURE_HOST}/posters/${slug}.png`,
    backdropUrl: `${FIXTURE_HOST}/backdrops/${slug}.png`,
    plot: `An ensemble drama set in a coastal town, where every episode follows a different household through the same week.`,
  }
})

/** Every artwork the fixture references, keyed by URL path, as SVG markup. */
export function artworkSvgByPath() {
  const out = new Map()
  for (const channel of CHANNELS) out.set(`/logos/${channel.slug}.png`, { svg: logoSvg(channel), width: 512, height: 512 })
  for (const movie of MOVIES) {
    out.set(`/posters/${movie.slug}.png`, { svg: posterSvg(movie.name, `${movie.year}  ·  ${movie.category}`, movie.paletteIndex), width: 480, height: 720 })
    out.set(`/backdrops/${movie.slug}.png`, { svg: backdropSvg(movie.name, movie.paletteIndex), width: 1280, height: 720 })
  }
  for (const show of SERIES) {
    out.set(`/posters/${show.slug}.png`, { svg: posterSvg(show.name, `${show.year}  ·  ${show.category}`, show.paletteIndex), width: 480, height: 720 })
    out.set(`/backdrops/${show.slug}.png`, { svg: backdropSvg(show.name, show.paletteIndex), width: 1280, height: 720 })
  }
  return out
}

// ---------------------------------------------------------------------------
// EPG
// ---------------------------------------------------------------------------
const PROGRAMME_TITLES = {
  News: ["Morning Briefing", "The Hour", "World Desk", "Markets Today", "Weather Watch", "Evening Briefing", "Headline Review", "Frontline Report", "Newsroom Live", "Late Edition"],
  Sports: ["Matchday Live", "Late Kick-Off", "Extra Time", "Trackside", "Court Report", "Ringside", "Summit Series", "Pitchside Tonight", "Grand Prix Review", "The Back Nine"],
  Movies: ["The Salt Road", "Paper Lanterns", "Northern Lights Express", "The Quiet Harbor", "Glass Orchard", "Last Ferry Home", "Ember Coast", "Signal Hill", "Winter Cartographer", "Blue Meridian"],
  Kids: ["Pip's Big Day", "Cloud Climbers", "Storytime", "Puzzle Parade", "Junior Explorers", "Bumble Beats", "Paper Boat Adventures", "Little Inventors", "Sky Garden", "Counting Stars"],
  Documentary: ["Deep Ocean", "Frozen Frontier", "Cities in Motion", "The Long Trail", "Life in the Canopy", "Makers", "Ancient Roads", "Night Sky", "Rivers of Ice", "The Salt Flats"],
  Music: ["Morning Mix", "Jazz After Dark", "Symphony Hour", "Folk Sessions", "Chart Countdown", "Late Night Lounge", "Acoustic Room", "Studio Sessions", "Sunday Strings", "Radio Hour"],
}

const PROGRAMME_DURATIONS_MIN = {
  News: [30, 60, 30, 60, 30],
  Sports: [120, 60, 90, 150, 60],
  Movies: [105, 120, 90, 135, 110],
  Kids: [15, 30, 20, 25, 30],
  Documentary: [45, 60, 50, 60, 55],
  Music: [30, 60, 45, 60, 30],
}

const PROGRAMME_DESCRIPTIONS = [
  "The stories shaping the day, with analysis from the studio and reports from the field.",
  "A closer look at the people and places behind the headlines.",
  "Live coverage with commentary, replays and reaction as it happens.",
  "An immersive journey through landscapes few people ever get to see.",
  "Songs, stories and games for curious young minds.",
  "A curated hour of performances recorded in front of a live audience.",
  "Tonight's feature presentation, shown in its original aspect ratio.",
]

function pad2(value) {
  return String(value).padStart(2, "0")
}

function xmltvStamp(date) {
  return `${date.getUTCFullYear()}${pad2(date.getUTCMonth() + 1)}${pad2(date.getUTCDate())}${pad2(date.getUTCHours())}${pad2(date.getUTCMinutes())}00 +0000`
}

export const DISPLAY_TIMEZONE = "America/New_York"

const hourFormatter = new Intl.DateTimeFormat("en-US", { hour: "numeric", hour12: false, timeZone: DISPLAY_TIMEZONE })
function localHour(ms) {
  return Number(hourFormatter.format(new Date(ms))) % 24
}

const NEWS_BY_HOUR = [
  [5, 10, ["Morning Briefing", "Newsroom Live"]],
  [10, 12, ["Markets Today", "The Hour"]],
  [12, 14, ["The Hour", "World Desk"]],
  [14, 17, ["World Desk", "Frontline Report"]],
  [17, 20, ["Evening Briefing", "Headline Review"]],
  [20, 22, ["Headline Review", "Frontline Report"]],
  [22, 24, ["Late Edition", "Newsroom Live"]],
  [0, 5, ["Newsroom Live", "Weather Watch"]],
]

function newsTitleForHour(hour, step) {
  const bucket = NEWS_BY_HOUR.find(([from, to]) => hour >= from && hour < to) || NEWS_BY_HOUR[0]
  return bucket[2][step % bucket[2].length]
}

/** Deterministic schedule per channel: covers now - 2h .. now + 7h, and "now" lands mid-programme. */
export function buildSchedule(nowMs) {
  const halfHour = 30 * 60 * 1000
  const windowStart = Math.floor(nowMs / halfHour) * halfHour - 2 * 60 * 60 * 1000
  const windowEnd = nowMs + 7 * 60 * 60 * 1000
  const schedule = new Map()
  CHANNELS.forEach((channel, channelIndex) => {
    const titles = PROGRAMME_TITLES[channel.group]
    const durations = PROGRAMME_DURATIONS_MIN[channel.group]
    const items = []
    // Stagger channels so boundaries never line up across the guide.
    let cursor = windowStart + (channelIndex % 4) * 15 * 60 * 1000
    let step = channelIndex
    while (cursor < windowEnd) {
      const durationMs = durations[step % durations.length] * 60 * 1000
      const title = channel.group === "News" ? newsTitleForHour(localHour(cursor), step) : titles[step % titles.length]
      items.push({
        start: cursor,
        stop: cursor + durationMs,
        title,
        description: PROGRAMME_DESCRIPTIONS[(step + channelIndex) % PROGRAMME_DESCRIPTIONS.length],
      })
      cursor += durationMs
      step++
    }
    schedule.set(channel.id, items)
  })
  return schedule
}

export function buildXmltv(schedule) {
  const parts = ['<?xml version="1.0" encoding="UTF-8"?>', '<tv generator-info-name="northwind-fixture">']
  for (const channel of CHANNELS) {
    parts.push(`  <channel id="${escapeXml(channel.tvgId)}">`)
    parts.push(`    <display-name>${escapeXml(channel.name)}</display-name>`)
    parts.push(`    <icon src="${escapeXml(channel.logoUrl)}"/>`)
    parts.push("  </channel>")
  }
  for (const channel of CHANNELS) {
    for (const item of schedule.get(channel.id)) {
      parts.push(`  <programme start="${xmltvStamp(new Date(item.start))}" stop="${xmltvStamp(new Date(item.stop))}" channel="${escapeXml(channel.tvgId)}">`)
      parts.push(`    <title lang="en">${escapeXml(item.title)}</title>`)
      parts.push(`    <desc lang="en">${escapeXml(item.description)}</desc>`)
      parts.push(`    <category lang="en">${escapeXml(channel.group)}</category>`)
      parts.push("  </programme>")
    }
  }
  parts.push("</tv>")
  return parts.join("\n")
}

// ---------------------------------------------------------------------------
// player_api.php
// ---------------------------------------------------------------------------
function unixSeconds(ms) {
  return Math.floor(ms / 1000)
}

function sqlStamp(ms) {
  const date = new Date(ms)
  return `${date.getUTCFullYear()}-${pad2(date.getUTCMonth() + 1)}-${pad2(date.getUTCDate())} ${pad2(date.getUTCHours())}:${pad2(date.getUTCMinutes())}:00`
}

function base64(text) {
  return Buffer.from(text, "utf8").toString("base64")
}

function epgListing(channel, item, index) {
  return {
    id: String(channel.id * 100 + index),
    epg_id: String(channel.id),
    title: base64(item.title),
    lang: "en",
    start: sqlStamp(item.start),
    end: sqlStamp(item.stop),
    description: base64(item.description),
    channel_id: channel.tvgId,
    start_timestamp: String(unixSeconds(item.start)),
    stop_timestamp: String(unixSeconds(item.stop)),
    now_playing: 0,
    has_archive: 0,
  }
}

export function userInfoResponse(nowMs) {
  return {
    user_info: {
      username: FIXTURE_USER,
      password: FIXTURE_PASS,
      message: "",
      auth: 1,
      status: "Active",
      exp_date: String(unixSeconds(nowMs + 365 * 24 * 60 * 60 * 1000)),
      is_trial: "0",
      active_cons: "0",
      created_at: String(unixSeconds(nowMs - 200 * 24 * 60 * 60 * 1000)),
      max_connections: "3",
      allowed_output_formats: ["m3u8", "ts"],
    },
    server_info: {
      url: "fixtures.invalid",
      port: "443",
      https_port: "443",
      server_protocol: "https",
      rtmp_port: "8001",
      timezone: DISPLAY_TIMEZONE,
      timestamp_now: unixSeconds(nowMs),
      time_now: sqlStamp(nowMs),
      process: true,
    },
  }
}

function liveCategories() {
  return LIVE_GROUPS.map((group, index) => ({ category_id: String(index + 1), category_name: group, parent_id: 0 }))
}

function liveStreams(nowMs) {
  return CHANNELS.map((channel, index) => ({
    num: channel.chno,
    name: channel.name,
    stream_type: "live",
    stream_id: channel.id,
    stream_icon: channel.logoUrl,
    epg_channel_id: channel.tvgId,
    added: String(unixSeconds(nowMs - (60 + index) * 24 * 60 * 60 * 1000)),
    category_id: String(LIVE_GROUPS.indexOf(channel.group) + 1),
    category_ids: [LIVE_GROUPS.indexOf(channel.group) + 1],
    custom_sid: "",
    tv_archive: 0,
    direct_source: "",
    tv_archive_duration: 0,
  }))
}

function vodCategories() {
  return MOVIE_CATEGORIES.map((category, index) => ({ category_id: String(10 + index), category_name: category, parent_id: 0 }))
}

function vodStreams(nowMs) {
  return MOVIES.map((movie, index) => ({
    num: index + 1,
    name: movie.name,
    stream_type: "movie",
    stream_id: movie.id,
    stream_icon: movie.posterUrl,
    rating: movie.rating,
    rating_5based: (Number(movie.rating) / 2).toFixed(1),
    added: String(unixSeconds(nowMs - (index * 13 + 2) * 60 * 60 * 1000)),
    category_id: String(movie.categoryId),
    category_ids: [movie.categoryId],
    container_extension: "mp4",
    custom_sid: "",
    direct_source: "",
    year: String(movie.year),
  }))
}

function seriesCategories() {
  return SERIES_CATEGORIES.map((category, index) => ({ category_id: String(20 + index), category_name: category, parent_id: 0 }))
}

function seriesRows(nowMs) {
  return SERIES.map((show, index) => ({
    num: index + 1,
    name: show.name,
    series_id: show.id,
    cover: show.posterUrl,
    plot: show.plot,
    cast: "Mara Ellison, Tobias Reyn, Ines Calder",
    director: "Ada Marchetti",
    genre: show.category,
    releaseDate: `${show.year}-03-14`,
    last_modified: String(unixSeconds(nowMs - (index * 9 + 5) * 60 * 60 * 1000)),
    rating: show.rating,
    rating_5based: (Number(show.rating) / 2).toFixed(1),
    backdrop_path: [show.backdropUrl],
    youtube_trailer: "",
    episode_run_time: "48",
    category_id: String(show.categoryId),
    category_ids: [show.categoryId],
  }))
}

function vodInfo(movieId, nowMs) {
  const movie = MOVIES.find((candidate) => candidate.id === movieId)
  if (!movie) return {}
  return {
    info: {
      kinopoisk_url: "",
      tmdb_id: "",
      name: movie.name,
      o_name: movie.name,
      cover_big: movie.posterUrl,
      movie_image: movie.posterUrl,
      releasedate: `${movie.year}-05-02`,
      episode_run_time: String(movie.runtime),
      youtube_trailer: "",
      director: "Ada Marchetti",
      actors: "Mara Ellison, Tobias Reyn, Ines Calder",
      cast: "Mara Ellison, Tobias Reyn, Ines Calder",
      description: movie.plot,
      plot: movie.plot,
      age: "12",
      mpaa_rating: "PG-13",
      rating_count_kinopoisk: 0,
      country: "Norway",
      genre: movie.category,
      backdrop_path: [movie.backdropUrl],
      duration_secs: movie.runtime * 60,
      duration: `${pad2(Math.floor(movie.runtime / 60))}:${pad2(movie.runtime % 60)}:00`,
      bitrate: 0,
      rating: movie.rating,
    },
    movie_data: {
      stream_id: movie.id,
      name: movie.name,
      added: String(unixSeconds(nowMs - 3 * 24 * 60 * 60 * 1000)),
      category_id: String(movie.categoryId),
      container_extension: "mp4",
      custom_sid: "",
      direct_source: "",
    },
  }
}

function seriesInfo(seriesId, nowMs) {
  const show = SERIES.find((candidate) => candidate.id === seriesId)
  if (!show) return {}
  const episodes = {}
  let episodeId = show.id * 100
  for (let season = 1; season <= show.seasons; season++) {
    episodes[String(season)] = Array.from({ length: 8 }, (_, index) => ({
      id: String(++episodeId),
      episode_num: index + 1,
      title: `Episode ${index + 1}`,
      container_extension: "mp4",
      season,
      added: String(unixSeconds(nowMs - (index + 1) * 24 * 60 * 60 * 1000)),
      custom_sid: "",
      direct_source: "",
      info: {
        movie_image: show.backdropUrl,
        plot: show.plot,
        duration_secs: 2880,
        duration: "00:48:00",
        rating: show.rating,
        releasedate: `${show.year}-03-${pad2(14 + index)}`,
      },
    }))
  }
  return {
    seasons: Array.from({ length: show.seasons }, (_, index) => ({
      season_number: index + 1,
      name: `Season ${index + 1}`,
      episode_count: 8,
      cover: show.posterUrl,
      air_date: `${show.year + index}-03-14`,
    })),
    info: {
      name: show.name,
      cover: show.posterUrl,
      plot: show.plot,
      cast: "Mara Ellison, Tobias Reyn, Ines Calder",
      director: "Ada Marchetti",
      genre: show.category,
      releaseDate: `${show.year}-03-14`,
      last_modified: String(unixSeconds(nowMs - 5 * 60 * 60 * 1000)),
      rating: show.rating,
      rating_5based: (Number(show.rating) / 2).toFixed(1),
      backdrop_path: [show.backdropUrl],
      youtube_trailer: "",
      episode_run_time: "48",
      category_id: String(show.categoryId),
    },
    episodes,
  }
}

function shortEpg(streamId, schedule, nowMs, limit) {
  const channel = CHANNELS.find((candidate) => candidate.id === streamId)
  if (!channel) return { epg_listings: [] }
  const items = schedule.get(channel.id).filter((item) => item.stop > nowMs).slice(0, limit)
  return { epg_listings: items.map((item, index) => epgListing(channel, item, index)) }
}

function fullEpg(streamId, schedule) {
  const channel = CHANNELS.find((candidate) => candidate.id === streamId)
  if (!channel) return { epg_listings: [] }
  return { epg_listings: schedule.get(channel.id).map((item, index) => epgListing(channel, item, index)) }
}

/** Answers a player_api.php request; returns the JSON-serialisable body. */
export function playerApiResponse(searchParams, schedule, nowMs) {
  const action = searchParams.get("action") || ""
  switch (action) {
    case "":
      return userInfoResponse(nowMs)
    case "get_live_categories":
      return liveCategories()
    case "get_live_streams":
      return liveStreams(nowMs)
    case "get_vod_categories":
      return vodCategories()
    case "get_vod_streams":
      return vodStreams(nowMs)
    case "get_series_categories":
      return seriesCategories()
    case "get_series":
      return seriesRows(nowMs)
    case "get_vod_info":
      return vodInfo(Number(searchParams.get("vod_id")), nowMs)
    case "get_series_info":
      return seriesInfo(Number(searchParams.get("series_id")), nowMs)
    case "get_short_epg":
      return shortEpg(Number(searchParams.get("stream_id")), schedule, nowMs, Number(searchParams.get("limit")) || 4)
    case "get_simple_data_table":
      return fullEpg(Number(searchParams.get("stream_id")), schedule)
    default:
      return []
  }
}

/** localStorage seed for the demo playlist plus a lived-in set of preferences. */
export function buildSeed(nowMs) {
  const playlists = {
    entries: [
      {
        _id: PLAYLIST_ID,
        title: PLAYLIST_TITLE,
        type: "xtream",
        serverUrl: FIXTURE_HOST,
        username: FIXTURE_USER,
        password: FIXTURE_PASS,
        addedAt: nowMs - 40 * 24 * 60 * 60 * 1000,
        lastUsedAt: nowMs - 60 * 60 * 1000,
      },
    ],
    selectedId: PLAYLIST_ID,
  }
  const movieById = (id) => MOVIES.find((movie) => movie.id === id)
  const showById = (id) => SERIES.find((show) => show.id === id)
  const channelById = (id) => CHANNELS.find((channel) => channel.id === id)
  const hoursAgo = (hours) => nowMs - hours * 60 * 60 * 1000
  const progVod = {}
  for (const [movieId, fraction, hours] of [[1001, 0.42, 2], [1005, 0.18, 26], [1009, 0.67, 50], [1016, 0.31, 74]]) {
    const movie = movieById(movieId)
    progVod[String(movieId)] = {
      position: Math.round(movie.runtime * 60 * fraction),
      duration: movie.runtime * 60,
      updatedAt: hoursAgo(hours),
      completed: false,
      name: movie.name,
      logo: movie.posterUrl,
    }
  }
  const watchVod = {}
  for (const [movieId, hours] of [[1003, 5], [1007, 30], [1012, 55], [1020, 80], [1024, 100]]) {
    const movie = movieById(movieId)
    watchVod[String(movieId)] = { ts: hoursAgo(hours), name: movie.name, logo: movie.posterUrl }
  }
  const watchSeries = {}
  for (const [seriesId, hours] of [[2002, 8], [2004, 40], [2010, 70]]) {
    const show = showById(seriesId)
    watchSeries[String(seriesId)] = { ts: hoursAgo(hours), name: show.name, logo: show.posterUrl }
  }
  const favLive = [101, 201, 501]
  const recLive = [101, 201, 501].map((channelId, index) => {
    const channel = channelById(channelId)
    return { id: channel.id, name: channel.name, logo: channel.logoUrl, ts: hoursAgo(index * 6 + 1) }
  })
  const prefs = {
    [PLAYLIST_ID]: {
      favLive,
      favVod: [1001, 1007, 1010, 1016],
      favSeries: [2001, 2004],
      favMetaLive: Object.fromEntries(favLive.map((channelId) => [String(channelId), { name: channelById(channelId).name, logo: channelById(channelId).logoUrl }])),
      favMetaVod: Object.fromEntries([1001, 1007, 1010, 1016].map((movieId) => [String(movieId), { name: movieById(movieId).name, logo: movieById(movieId).posterUrl }])),
      favMetaSeries: Object.fromEntries([2001, 2004].map((seriesId) => [String(seriesId), { name: showById(seriesId).name, logo: showById(seriesId).posterUrl }])),
      recLive,
      recVod: [],
      recSeries: [],
      progVod,
      watchVod,
      watchSeries,
    },
  }
  return { playlists, prefs }
}
