# Footage manifest

Recorded 2026-09-02T05:09:32.572Z from the production build (`pnpm build`, served by `astro preview` at http://127.0.0.1:4321) against a fictional Xtream provider fixture ("Northwind IPTV": 40 live channels in 6 groups, 24 movies, 12 series, XMLTV EPG generated around the real current time). Dark theme, English, America/New_York clock, animations on (no perf mode).

Capture method: Chromium headless shell driven frame by frame (virtual time + `HeadlessExperimental.beginFrame`), so every frame is exactly 1/60 s of app time and the output is true constant 60 fps with no dropped or duplicated frames. Desktop clips are captured at native 1920x1080 (device scale 1); phone clips at native 3x (1236x2745, scaled to 2744 rows for H.264). Encoded H.264 (libx264, CRF 14, yuv420p, faststart). The mouse pointer is never drawn in headless capture: hover states show, the cursor itself does not.

Footage lives in `../remotion/public/footage/`, stills in `stills/<clip>-end.png` next to this file. Desktop stills (3840x2160, 2x device scale) are re-rendered end states shot in regular headless Chromium; phone stills (1236x2745, 3x) are the last captured frame of the clip.

| Clip | Resolution | FPS | Duration | Frames |
|---|---|---|---|---|
| `splash.mp4` | 1920x1080 | 60 (CFR) | 5.73 s | 344 |
| `hub.mp4` | 1920x1080 | 60 (CFR) | 7.02 s | 421 |
| `livetv.mp4` | 1920x1080 | 60 (CFR) | 7.20 s | 432 |
| `epg.mp4` | 1920x1080 | 60 (CFR) | 5.83 s | 350 |
| `tv-home.mp4` | 1920x1080 | 60 (CFR) | 7.10 s | 426 |
| `tv-live.mp4` | 1920x1080 | 60 (CFR) | 5.50 s | 330 |
| `search.mp4` | 1920x1080 | 60 (CFR) | 4.18 s | 251 |
| `phone-hub.mp4` | 1236x2744 | 60 (CFR) | 6.03 s | 362 |
| `phone-livetv.mp4` | 1236x2744 | 60 (CFR) | 6.03 s | 362 |

## splash.mp4

- File: `remotion/public/footage/splash.mp4` (h264, yuv420p, ~4635 kb/s)
- Resolution: 1920x1080
- Frame rate: 60 fps constant, 344 frames
- Duration: 5.73 s
- Still: `capture/stills/splash-end.png`
- What happens: Fresh load of / with no xt_splash_done: nebula backdrop fades in, the infinity mark draws itself, the comet orbits the figure-8, the wordmark appears, then the splash fades (600 ms) into the populated hub.
- Key moments:
  - 0.20 s: navigation starts
  - 0.27 s: splash visible
  - 4.13 s: splash removed, hub revealed

## hub.mp4

- File: `remotion/public/footage/hub.mp4` (h264, yuv420p, ~1131 kb/s)
- Resolution: 1920x1080
- Frame rate: 60 fps constant, 421 frames
- Duration: 7.02 s
- Still: `capture/stills/hub-end.png`
- What happens: Hub loads from a dark frame: marquee, the three tiles stagger in, favourites / continue-watching strips fill. Then the pointer (not drawn in headless capture) glides Live TV -> Movies -> Series; each tile lifts and its border and heading take the accent colour.
- Key moments:
  - 0.15 s: navigation starts
  - 0.22 s: hub painted; tiles stagger in over the next 0.6 s, strips fill
  - 1.72 s: pointer glides to Live TV tile
  - 3.52 s: pointer glides to Movies tile
  - 5.12 s: pointer glides to Series tile

## livetv.mp4

- File: `remotion/public/footage/livetv.mp4` (h264, yuv420p, ~808 kb/s)
- Resolution: 1920x1080
- Frame rate: 60 fps constant, 432 frames
- Duration: 7.20 s
- Still: `capture/stills/livetv-end.png`
- What happens: Channel list with logos, channel numbers, now-playing titles and progress bars. Focus steps down 4 rows (600 ms apart), Enter tunes the 5th channel: the player leaves the idle state and the programme panel below fills with now/next.
- Key moments:
  - 0.90 s: focus lands on first channel
  - 1.60 s: ArrowDown x4 begins
  - 4.00 s: Enter tunes channel 5

## epg.mp4

- File: `remotion/public/footage/epg.mp4` (h264, yuv420p, ~1242 kb/s)
- Resolution: 1920x1080
- Frame rate: 60 fps constant, 350 frames
- Duration: 5.83 s
- Still: `capture/stills/epg-end.png`
- What happens: Programme guide: channel column with logos, half-hour time header, now-line, current programmes highlighted. eased vertical drift of 560 px over 4 s (the 6-hour grid fits inside the 1920 px viewport, so there is no horizontal overflow to scroll).
- Key moments:
  - 0.80 s: vertical drift starts
  - 4.83 s: drift ends

## tv-home.mp4

- File: `remotion/public/footage/tv-home.mp4` (h264, yuv420p, ~2180 kb/s)
- Resolution: 1920x1080
- Frame rate: 60 fps constant, 426 frames
- Duration: 7.10 s
- Still: `capture/stills/tv-home-end.png`
- What happens: TV home (/tv): hero focused at start. ArrowDown drops the glide ring onto the first Favorites card, ArrowRight x3 (700 ms apart) slides across to the first movie poster while the hero crossfades per card, ArrowDown scrolls to the Continue watching rail, ArrowRight x2.
- Key moments:
  - 0.90 s: ArrowDown: hero -> first Favorites card
  - 1.80 s: ArrowRight x3 across the rail
  - 3.90 s: ArrowDown: Continue watching rail
  - 4.80 s: ArrowRight x2

## tv-live.mp4

- File: `remotion/public/footage/tv-live.mp4` (h264, yuv420p, ~1545 kb/s)
- Resolution: 1920x1080
- Frame rate: 60 fps constant, 330 frames
- Duration: 5.50 s
- Still: `capture/stills/tv-live-end.png`
- What happens: TV Live (/tv/live) on the All channels group: category column, channel rows with logo, now/next and progress, programme guide panel on the right. Focus steps down 5 channels (700 ms apart); the guide panel crossfades to each focused channel with its current programme and Up next list.
- Key moments:
  - 1.00 s: ArrowDown x5 begins

## search.mp4

- File: `remotion/public/footage/search.mp4` (h264, yuv420p, ~502 kb/s)
- Resolution: 1920x1080
- Frame rate: 60 fps constant, 251 frames
- Duration: 4.18 s
- Still: `capture/stills/search-end.png`
- What happens: Search page with the input focused; "north" is typed one character per 120 ms and results narrow live to Northwind News plus the Northern Lights Express movie.
- Key moments:
  - 0.80 s: typing "north" begins
  - 1.38 s: results settle

## phone-hub.mp4

- File: `remotion/public/footage/phone-hub.mp4` (h264, yuv420p, ~4109 kb/s)
- Resolution: 1236x2744 (portrait)
- Frame rate: 60 fps constant, 362 frames
- Duration: 6.03 s
- Still: `capture/stills/phone-hub-end.png`
- What happens: Phone hub (412x915 CSS px @3x, portrait): marquee, tiles and strips; slow eased scroll down 900 px over 4.2 s.
- Key moments:
  - 0.90 s: scroll starts
  - 5.13 s: scroll ends

## phone-livetv.mp4

- File: `remotion/public/footage/phone-livetv.mp4` (h264, yuv420p, ~1714 kb/s)
- Resolution: 1236x2744 (portrait)
- Frame rate: 60 fps constant, 362 frames
- Duration: 6.03 s
- Still: `capture/stills/phone-livetv-end.png`
- What happens: Phone Live TV (412x915 CSS px @3x, portrait): idle player card on top, channel list with logos, numbers and now-playing progress below; slow eased scroll of 3 rows (168 px) over 4.2 s.
- Key moments:
  - 0.90 s: scroll starts
  - 5.13 s: scroll ends

## Re-running

```bash
# from the repo root, with the preview server running in another terminal:
#   pnpm build && pnpm preview --host 127.0.0.1 --port 4321
cd tools/promo-video
node capture/record.mjs                          # all clips
node capture/record.mjs tv-home tv-live          # only some clips (names = file stems)
node capture/record.mjs --stills-only tv-home    # redo only the 2x desktop still(s)
node capture/write-manifest.mjs                  # regenerate this file from last-run.json
```

`record.mjs` needs the repo's `playwright` package (from `pnpm install` at the repo root), Playwright's Chromium and headless shell (`npx playwright install chromium`), and `ffmpeg`/`ffprobe` on PATH. Override with `XT_BASE_URL`, `XT_OUT_DIR`, `XT_CHROMIUM`, `XT_HEADLESS_SHELL`. See ../README.md.
