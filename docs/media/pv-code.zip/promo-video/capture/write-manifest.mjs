// Writes capture/MANIFEST.md from last-run.json (clip notes + markers) and ffprobe of each MP4.
// Honours XT_OUT_DIR the same way record.mjs does.
import { readFile, writeFile, stat } from "node:fs/promises"
import { execFile } from "node:child_process"
import { promisify } from "node:util"
import path from "node:path"
import { fileURLToPath } from "node:url"

const execFileAsync = promisify(execFile)
const CAPTURE_DIR = path.dirname(fileURLToPath(import.meta.url))
const PROMO_DIR = path.resolve(CAPTURE_DIR, "..")
const OUT_DIR = process.env.XT_OUT_DIR ? path.resolve(process.env.XT_OUT_DIR) : null
const FOOTAGE_DIR = OUT_DIR ? path.join(OUT_DIR, "footage") : path.join(PROMO_DIR, "remotion", "public", "footage")
const LAST_RUN_FILE = OUT_DIR ? path.join(OUT_DIR, "last-run.json") : path.join(CAPTURE_DIR, "last-run.json")
const MANIFEST_FILE = OUT_DIR ? path.join(OUT_DIR, "MANIFEST.md") : path.join(CAPTURE_DIR, "MANIFEST.md")
const CLIP_ORDER = ["splash", "hub", "livetv", "epg", "tv-home", "tv-live", "search", "phone-hub", "phone-livetv"]

async function probe(file) {
  const { stdout } = await execFileAsync("ffprobe", [
    "-v", "error", "-select_streams", "v:0",
    "-show_entries", "stream=codec_name,width,height,r_frame_rate,nb_frames,pix_fmt:format=duration,bit_rate",
    "-of", "json", file,
  ])
  const parsed = JSON.parse(stdout)
  const stream = parsed.streams[0]
  return {
    codec: stream.codec_name,
    width: stream.width,
    height: stream.height,
    fps: stream.r_frame_rate,
    frames: Number(stream.nb_frames),
    pixFmt: stream.pix_fmt,
    durationSec: Number(parsed.format.duration),
    kbps: Math.round(Number(parsed.format.bit_rate) / 1000),
  }
}

function formatSeconds(value) {
  return `${value.toFixed(2)} s`
}

async function main() {
  const run = JSON.parse(await readFile(LAST_RUN_FILE, "utf8"))
  const clipsByName = new Map(run.clips.map((clip) => [clip.name, clip]))
  const lines = []
  lines.push("# Footage manifest")
  lines.push("")
  lines.push(`Recorded ${run.recordedAt} from the production build (\`pnpm build\`, served by \`astro preview\` at http://127.0.0.1:4321) against a fictional Xtream provider fixture ("Northwind IPTV": 40 live channels in 6 groups, 24 movies, 12 series, XMLTV EPG generated around the real current time). Dark theme, English, America/New_York clock, animations on (no perf mode).`)
  lines.push("")
  lines.push("Capture method: Chromium headless shell driven frame by frame (virtual time + `HeadlessExperimental.beginFrame`), so every frame is exactly 1/60 s of app time and the output is true constant 60 fps with no dropped or duplicated frames. Desktop clips are captured at native 1920x1080 (device scale 1); phone clips at native 3x (1236x2745, scaled to 2744 rows for H.264). Encoded H.264 (libx264, CRF 14, yuv420p, faststart). The mouse pointer is never drawn in headless capture: hover states show, the cursor itself does not.")
  lines.push("")
  lines.push("Footage lives in `../remotion/public/footage/`, stills in `stills/<clip>-end.png` next to this file. Desktop stills (3840x2160, 2x device scale) are re-rendered end states shot in regular headless Chromium; phone stills (1236x2745, 3x) are the last captured frame of the clip.")
  lines.push("")
  lines.push("| Clip | Resolution | FPS | Duration | Frames |")
  lines.push("|---|---|---|---|---|")
  const details = []
  for (const name of CLIP_ORDER) {
    const clip = clipsByName.get(name)
    if (!clip) continue
    const file = path.join(FOOTAGE_DIR, `${name}.mp4`)
    let info
    try {
      await stat(file)
      info = await probe(file)
    } catch {
      continue
    }
    lines.push(`| \`${name}.mp4\` | ${info.width}x${info.height} | ${info.fps.replace("/1", "")} (CFR) | ${formatSeconds(info.durationSec)} | ${info.frames} |`)
    const section = []
    section.push(`## ${name}.mp4`)
    section.push("")
    section.push(`- File: \`remotion/public/footage/${name}.mp4\` (${info.codec}, ${info.pixFmt}, ~${info.kbps} kb/s)`)
    section.push(`- Resolution: ${info.width}x${info.height}${name.startsWith("phone") ? " (portrait)" : ""}`)
    section.push(`- Frame rate: ${info.fps.replace("/1", "")} fps constant, ${info.frames} frames`)
    section.push(`- Duration: ${formatSeconds(info.durationSec)}`)
    section.push(`- Still: \`capture/stills/${path.basename(clip.still || `${name}-end.png`)}\``)
    section.push(`- What happens: ${clip.notes}`)
    if (clip.trimHint) section.push(`- Editing note: ${clip.trimHint}`)
    if (clip.markers?.length) {
      section.push("- Key moments:")
      for (const marker of clip.markers) section.push(`  - ${marker.atSec.toFixed(2)} s: ${marker.label}`)
    }
    section.push("")
    details.push(section.join("\n"))
  }
  lines.push("")
  lines.push(...details)
  lines.push("## Re-running")
  lines.push("")
  lines.push("```bash")
  lines.push("# from the repo root, with the preview server running in another terminal:")
  lines.push("#   pnpm build && pnpm preview --host 127.0.0.1 --port 4321")
  lines.push("cd tools/promo-video")
  lines.push("node capture/record.mjs                          # all clips")
  lines.push("node capture/record.mjs tv-home tv-live          # only some clips (names = file stems)")
  lines.push("node capture/record.mjs --stills-only tv-home    # redo only the 2x desktop still(s)")
  lines.push("node capture/write-manifest.mjs                  # regenerate this file from last-run.json")
  lines.push("```")
  lines.push("")
  lines.push("`record.mjs` needs the repo's `playwright` package (from `pnpm install` at the repo root), Playwright's Chromium and headless shell (`npx playwright install chromium`), and `ffmpeg`/`ffprobe` on PATH. Override with `XT_BASE_URL`, `XT_OUT_DIR`, `XT_CHROMIUM`, `XT_HEADLESS_SHELL`. See ../README.md.")
  lines.push("")
  await writeFile(MANIFEST_FILE, lines.join("\n"))
  console.log(`wrote ${MANIFEST_FILE}`)
}

main().catch((error) => {
  console.error(error)
  process.exit(1)
})
