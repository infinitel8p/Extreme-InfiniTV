# Promo video toolchain

Everything needed to edit and re-render the Extreme InfiniTV promo video (1920x1080 and 1080x1080, 30 fps, about 33 s). The folder is self-contained: footage, fonts, logos, audio, the Remotion composition and the Playwright recorder that produced the footage are all here. Paths inside the scripts are derived from their own location, so the folder works from any checkout on Windows, macOS or Linux.

```
tools/promo-video/
  README.md            this file
  STORYBOARD.md        the brief every beat was built from
  capture/             records the app UI into footage (Playwright + Chromium headless shell + ffmpeg)
    record.mjs         the recorder; clip definitions live at the bottom of the file
    fixture.mjs        the fictional "Northwind IPTV" provider the app is pointed at while recording
    write-manifest.mjs regenerates MANIFEST.md from last-run.json
    MANIFEST.md        per-clip durations, resolutions and time markers
    last-run.json      notes and markers from the last recording (committed, paths are relative)
    stills/            end-state PNGs of each clip (desktop 3840x2160, phone 1236x2745), for reference only
  remotion/            the video itself (Remotion 4, React, TypeScript)
    src/               composition source (see "Change the edit")
    public/            footage, fonts, logos, audio the composition loads
    scripts/           check-clips.mjs, prepare-music.mjs
  audio/
    LICENSES.md        provenance and licence of every audio file, plus evaluated alternatives
    candidate-1.mp3    raw music source; prepare-music.mjs masters it into remotion/public/audio/music.wav
  out/                 rendered videos (gitignored)
```

All footage shows fictional content: the recorder feeds the app a generated provider ("Northwind IPTV", 40 channels, 24 movies, 12 series, synthetic artwork and EPG) and blocks every other network request. No real provider, stream or logo appears. Audio licences are listed in `audio/LICENSES.md`; everything in the current cut is CC0 or owned by the project.

## Prerequisites

- Node 22 or newer (the recorder uses the built-in `WebSocket` and `fetch`).
- pnpm, only to build and serve the app when re-recording footage (`pnpm install` at the repo root also provides the `playwright` package the recorder imports).
- ffmpeg and ffprobe on PATH. Remotion bundles its own ffmpeg for rendering, so this is needed only for recording footage, `npm run check:clips` and audio preparation.
- Playwright browsers, only for recording: `npx playwright install chromium` in the repo root installs both the full browser and the headless shell that the recorder needs. Override the binaries with `XT_CHROMIUM` and `XT_HEADLESS_SHELL` if they live elsewhere.

One-time setup for the composition:

```bash
cd tools/promo-video/remotion
npm ci
```

## Workflow A: change the edit (copy, timing, colours, layout)

Where things live in `remotion/src/`:

| What | File |
|---|---|
| Beat boundaries, clip in-points, caption enter/exit frames, inner cuts, SFX cue frames, music offset | `timeline.ts` |
| Copy and layout of each beat (headline, sub, eyebrow, frame sizes, caption position) | `beats/ColdOpen.tsx`, `beats/Hub.tsx`, `beats/LiveTv.tsx`, `beats/Couch.tsx`, `beats/Search.tsx`, `beats/Pocket.tsx`, shared sizes in `beats/layout.ts` |
| End card (logo, wordmark, platform pills, store labels) | `components/EndCard.tsx` |
| Colours, font stack, easing, FPS | `theme.ts` |
| Music level and fades, which SFX plays at which cue, SFX levels | `Soundtrack.tsx` (cue frames come from `timeline.ts`) |
| Shared motion helpers | `motion.ts` |
| Composition list (`promo` 1920x1080, `promo-square` 1080x1080) | `Root.tsx`, `Promo.tsx` |

Then, from `tools/promo-video/remotion`:

```bash
npm run typecheck        # type errors show up here before a long render does
npm run render:preview   # quick look: 960x540, every second frame, ../out/preview/preview.mp4
npm run render           # final 1920x1080 H.264 to ../out/extreme-infinitv-promo.mp4
npm run render:square    # final 1080x1080 to ../out/extreme-infinitv-promo-square.mp4
npm run studio           # Remotion Studio in the browser for scrubbing and live editing
```

If you move a beat boundary or a clip in-point, run `npm run check:clips`: it confirms that each footage clip is long enough for the span the timeline reads from it. A failing clip means either shorten the span or re-record that clip longer (Workflow B).

## Workflow B: re-record footage after UI changes

The footage is a deterministic capture of the built app: Chromium headless shell is stepped one frame at a time with virtual time, so every frame is exactly 1/60 s of app time regardless of machine speed. Clip definitions (routes, key presses, scroll distances, durations, markers) are the `desktopClips`, `phoneClips` and `stillScenes` objects at the bottom of `capture/record.mjs`.

1. Build and serve the app from the repo root, in its own terminal:

   ```bash
   pnpm build
   pnpm preview --host 127.0.0.1 --port 4321
   ```

2. Record, from `tools/promo-video`:

   ```bash
   node capture/record.mjs                       # every clip (1 to 7 minutes per clip depending on clip and machine)
   node capture/record.mjs tv-home tv-live       # only the named clips (names are the mp4 stems)
   node capture/record.mjs --stills-only hub     # only redo the 2x reference still
   ```

   Output goes to `remotion/public/footage/<clip>.mp4` and `capture/stills/<clip>-end.png`; `capture/last-run.json` is updated with notes and markers. Set `XT_OUT_DIR` to write everything somewhere else instead, `XT_BASE_URL` if the preview server is not on `http://127.0.0.1:4321`.

3. Refresh the manifest and check the lengths still fit the edit:

   ```bash
   node capture/write-manifest.mjs
   cd remotion && npm run check:clips
   ```

4. Re-render (Workflow A).

Notes:

- The provider data the app shows comes from `capture/fixture.mjs` (fictional Northwind IPTV). Change channel names, artwork colours or the EPG there if the footage should show different content. The schedule is generated around the real current time so "now playing" always looks live.
- The recorder resolves the app's selectors (`#hub-tiles`, `.channel-row`, `#epg-grid`, `[data-focus-key]`, `main input[type="search"]` and so on). After a UI redesign, update the matching clip in `record.mjs` if a wait or a key sequence no longer lands where it should; the log prints a phase timeline so the stuck step is easy to find.
- Each clip runs in a fresh browser, so a wedged renderer never affects the next clip.

## Workflow C: swap the music

1. Put the new source file in `audio/` and record its licence in `audio/LICENSES.md` (title, author, URL, exact licence, required credit line).
2. Master it into `remotion/public/audio/music.wav`:

   ```bash
   cd tools/promo-video/remotion
   npm run prepare:music -- ../audio/new-track.mp3
   ```

   The script applies +1.7 dB and a limiter with a -1 dBTP ceiling (edit the filter chain in `scripts/prepare-music.mjs` if the new track needs a different gain), then prints the integrated loudness and true peak.

3. Update `musicStartSeconds` in `remotion/src/timeline.ts` so the track's swell lands on the end card (beat 6 starts at 28.6 s), and adjust `MUSIC_PREGAIN_DB` in `remotion/src/Soundtrack.tsx` if the SFX balance changes. Target about -18 LUFS integrated for the music bed under the SFX.
4. Render, then measure the finished mix:

   ```bash
   ffmpeg -hide_banner -i ../out/extreme-infinitv-promo.mp4 -af ebur128=peak=true -f null - 2>&1 | tail -14
   ```

   Look at the `I:` (integrated LUFS) and `Peak:` lines. Adjust and re-render until nothing clips and the cuts stay audible over the bed.

## Prompting Claude Code

Claude Code can work this folder unattended when the request names the target file or clip. Examples:

- "In tools/promo-video, change the beat 4 headline to 'Search everything at once.' and re-render the preview." (It edits `remotion/src/beats/Search.tsx`, runs `npm run typecheck` and `npm run render:preview`, and reports the output path.)
- "The TV rail was redesigned. Build the app, start the preview server, re-record tv-home and tv-live with tools/promo-video/capture/record.mjs, regenerate the manifest, run check:clips and re-render the preview." (It runs Workflow B for those two clips, fixing selectors in `record.mjs` if the recorder can no longer find the rail, then Workflow A.)

Other requests that map directly onto files: retime a caption (`timeline.ts`), change the accent colour (`theme.ts`), move an SFX cue (`timeline.ts` `sfxFrames`), replace a platform pill on the end card (`components/EndCard.tsx`), lengthen a clip (the clip's `advance` calls in `record.mjs`, then re-record it).

## Repository notes

- The repo's root `.gitignore` ignores `tools/` wholesale. To commit this folder, change that line to `tools/*` and add `!tools/promo-video/` below it.
- Binary size: footage 13 MB, `music.wav` 15 MB, stills 10 MB, music source 1.4 MB. Consider Git LFS for `remotion/public/footage/`, `remotion/public/audio/music.wav` and `capture/stills/` if repository size matters. `music.wav` can be regenerated from `audio/candidate-1.mp3` with `npm run prepare:music`, and the stills are reference material only (the composition does not load them).
- `out/` and `capture/.frames/` (intermediate PNG frames during recording) are gitignored.

## Windows notes

- Run the recorder from a normal terminal (PowerShell or cmd), not Git Bash, so Node's paths stay native.
- ffmpeg and ffprobe must be on PATH for the recorder and the scripts; Remotion's own render does not need them.
- Full recording writes about 400 PNG frames per clip into `capture/.frames/`; exclude that folder from real-time antivirus scanning if capture is slow.
- If `npx playwright install chromium` was run from a different Node project, Playwright still finds the browsers in `%LOCALAPPDATA%\ms-playwright` as long as the `playwright` version installed at the repo root matches the downloaded revision. A mismatch shows up as "Executable doesn't exist"; run the install command again from the repo root.
