# Extreme InfiniTV product video: storyboard

Paths below are relative to `tools/promo-video/`. The implementation of each beat lives in `remotion/src/beats/`, timings in `remotion/src/timeline.ts`.

Target: 1920x1080, 30 fps, about 33 s, H.264 MP4 with AAC audio. Reused for README (GitHub renders MP4 in issues/README via drag-in upload), Microsoft Store and Google Play listing videos, and social posts. A 1080x1080 square variant is a stretch goal.

## Brand rules (from the project's design context)

- Calm. Focused. Refined. Cinema lobby, not games arcade. No neon, no glassmorphism, no loud gradients, no RGB gamer styling, no serif or italic hero type.
- Palette: cool slate foundation (#0b0d12 background, #14171f surfaces, #9aa3b2 muted text, #f4f6fa primary text) with one restrained fuchsia accent (#d946ef family; the app uses a soft fuchsia around #c84bd8 / #a855f7 for progress fills and focus rings). Accent is for focus, "now playing", progress, one word of emphasis. Never large accent fills.
- Typography: Geist Variable only (copies of the app's `@fontsource-variable/geist` latin + latin-ext woff2 files live in `remotion/public/fonts/`, loaded via @font-face). Headlines 500-600 weight, tight tracking (-0.02em), captions 400-500. Sentence case, no ALL CAPS except tiny eyebrow labels with wide tracking.
- Motion: signature easing cubic-bezier(0.16, 1, 0.3, 1) (an "out-expo" feel). Enter durations 480-720 ms. Nothing bounces. Nothing spins. Micro-parallax and slow scale (1.00 -> 1.04) on footage is the most motion a background gets. Cuts are either hard cuts on the beat or 300-400 ms crossfades; no wipes, no slides from off-screen except captions rising 12-16 px while fading in.
- Content over chrome: the recorded UI is the hero; captions are short and sit in the lower third or the left safe area, never over the important part of the footage.

## Assets

- Footage: `remotion/public/footage/*.mp4` (60 fps CFR, see `capture/MANIFEST.md` for timestamps). Stills: `capture/stills/`.
- Logo: `remotion/public/logos/logo-mark.svg` (colour mark), `logo-mark-mono-white.svg`, `readme-lockup-2x.png` (mark + wordmark), copied from the repo's `src-tauri/icons/logos/`. Wordmark styling: "Extreme Infini" in white with "TV" in the accent, as in the app header.
- Music: `audio/candidate-1.mp3`, mastered to `remotion/public/audio/music.wav` by `npm run prepare:music` ("Unpretentious Reveal (no drums)", CC0, 59.5 s, gentle swell peaking around 45 s). Use an in-point so that the swell lands on the platform/CTA beat (roughly music offset 12-14 s), fade in 0.5 s at the start, fade out over the last 1.5 s, level around -18 LUFS integrated.
- SFX (`remotion/public/audio/sfx/`, licences in `audio/LICENSES.md`): impact-low.mp3 on the logo reveal (quiet, -14 dB relative), whoosh-soft.mp3 on the two major scene changes (into TV beat, into phone beat) at -16 dB, ui-nav.wav ticks synced to the TV focus-ring moves (very quiet, -20 dB, these are the app's own sounds), ui-select.wav once on the channel tune in the Live TV beat. Do not overdo SFX: at most 12 total events.

## Timeline (seconds)

### 0.0 - 3.2  Cold open
Black. splash.mp4 from its 0.27 s mark: nebula, infinity mark draws itself, wordmark appears. Show it full-bleed, no frame. Slight slow scale 1.03 -> 1.00. impact-low at the moment the mark completes (about 1.6 s into the clip). At 3.2 s hard cut on the beat (do not use the clip's own fade into the hub; we cut before 4.1 s).

### 3.2 - 8.0  Beat 1: The hub
hub.mp4 from 0.9 s (tiles already staggered, then pointer glides across Live TV, Movies, Series). Present it inside a minimal desktop window frame: 12 px radius, 1 px rgba(255,255,255,0.08) border, soft shadow, sitting on the slate background, scaled to about 86% width, entering with scale 0.96 -> 1.0 and opacity over 600 ms with the signature easing. Slow drift upward 10 px across the beat.
Caption (lower left, eyebrow + headline):
- eyebrow: "EXTREME INFINITV"
- headline: "Every playlist. One calm place."
- sub: "Xtream Codes and M3U, side by side."
Caption enters at 3.6 s, exits (fade + rise) at 7.6 s.

### 8.0 - 13.6  Beat 2: Live TV and the guide
Hard cut to livetv.mp4 from 1.4 s (focus stepping down, Enter tunes channel at 4.0 s in-clip, so the tune lands at about 10.6 s on the timeline). Same window frame, but this time let it fill 92% width so the channel list is legible. ui-select.wav on the tune.
At 11.4 s crossfade (350 ms) to epg.mp4 from 1.0 s (guide drifting) and let it run to 13.6.
Caption: headline "Live TV with a real guide." sub "EPG, now and next, catch-up replay." Enters 8.4 s, exits 13.2 s.

### 13.6 - 20.4  Beat 3: Built for the couch (hero beat)
whoosh-soft at 13.5 s. Cut to tv-home.mp4 from 0.5 s, FULL-BLEED (this is the 10-foot UI, it should feel like a TV), with a slow scale 1.00 -> 1.03 over the beat. ui-nav ticks on the focus moves at the manifest timestamps (0.9, 1.8, 2.5, 3.2, 3.9, 4.8, 5.5 s in-clip minus the 0.5 s in-point).
At 17.4 s crossfade (350 ms) to tv-live.mp4 from 1.0 s (guide panel crossfading as focus steps down) until 20.4.
Caption, this time top-left over the dark hero area with a subtle 60% gradient scrim behind it if needed for contrast: headline "Made for the remote." sub "D-pad first. Focus you can see from the sofa." Enters 14.0 s, exits 20.0 s.

### 20.4 - 24.2  Beat 4: Search
Hard cut to search.mp4 from 0.4 s in the window frame at 86% width: typing "north", results narrow. Caption: headline "Find anything in a keystroke." sub "Channels, movies, series, actors. Ctrl+K." Enters 20.8, exits 23.8.

### 24.2 - 28.6  Beat 5: In your pocket
whoosh-soft at 24.1. Two phone clips side by side on the slate background, each inside a rounded phone frame (about 44 px radius at display size, 2 px border rgba(255,255,255,0.10), dark bezel), phone-hub.mp4 left and phone-livetv.mp4 right, staggered entrance (right one 120 ms later), rising 24 px while fading in. Phones occupy about 62% of the height, centred slightly left so the caption can sit on the right third.
Caption (right third, left-aligned): headline "And in your pocket." sub "Phone, tablet, TV, desktop, web. One codebase." Enters 24.7, exits 28.2.

### 28.6 - 33.0  Beat 6: Platforms and CTA
Crossfade to a clean end card on the slate background. Centre: logo mark (colour) scaling in 0.9 -> 1.0, wordmark "Extreme InfiniTV" (TV in accent) below it. Under that, a single row of six platform pills entering with 60 ms stagger: Windows, Android, Android TV, macOS, Linux, Web. Pills: 999 px radius, 1 px border rgba(255,255,255,0.10), surface fill, Geist 500 at 22-24 px. Use Tabler outline icons where available in the repo's `@tabler/icons` package, inlined as SVG paths in `remotion/src/components/icons.tsx` (brand-windows, brand-android, device-tv, brand-apple, brand-ubuntu or brand-debian, world). Inline the SVG paths; do not load icon fonts.
Below the pills, one quiet line at 40% opacity: "Open source. GPL-3.0. github.com/infinitel8p/Extreme-InfiniTV".
Below that, three store labels as small text badges: "Microsoft Store", "Google Play", "Snap Store" (plain text pills, no official store artwork, since official badges carry usage rules).
Music swell should peak around 29-30 s, then fade out over the last 1.5 s. Everything holds still from 31.2 s, fades to black over the last 0.6 s.

## Square variant (stretch)
1080x1080, same timeline, desktop clips shown letterboxed inside the window frame at full width with captions moved above the frame, phones side by side smaller, end card unchanged.

## Acceptance
- Every caption is on screen at least 2.6 s.
- No caption overlaps the focused UI element of the underlying footage.
- Text is legible at 50% scale (README preview size).
- No frame shows a black gap between clips, a frozen last frame, or a clip that has run out (check clip durations vs. in-points).
- Audio: no clipping, music never masks the visual cuts, SFX barely noticeable.
