// Masters the music bed: +1.7 dB gain, then a lookahead limiter with a -1 dBTP ceiling, written as
// 24-bit PCM to public/audio/music.wav. Needs ffmpeg on PATH. Run from the remotion folder:
//   npm run prepare:music                 (uses ../audio/candidate-1.mp3)
//   npm run prepare:music -- ../audio/other-track.mp3
import { execFileSync, spawnSync } from "node:child_process";
import path from "node:path";
import { fileURLToPath } from "node:url";

const REMOTION_DIR = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const sourceFile = path.resolve(process.argv[2] || path.join(REMOTION_DIR, "..", "audio", "candidate-1.mp3"));
const targetFile = path.join(REMOTION_DIR, "public", "audio", "music.wav");

execFileSync(
  "ffmpeg",
  ["-y", "-v", "error", "-i", sourceFile, "-af", "volume=1.7dB,alimiter=limit=0.891:attack=5:release=80:level=false", "-c:a", "pcm_s24le", targetFile],
  { stdio: "inherit" },
);
console.log(`wrote ${targetFile}`);

const loudness = spawnSync("ffmpeg", ["-hide_banner", "-i", targetFile, "-af", "ebur128=peak=true", "-f", "null", "-"], { encoding: "utf8" });
const summary = loudness.stderr.split("\n").slice(-14).filter((line) => /I:|Peak:/.test(line));
console.log(summary.join("\n"));
