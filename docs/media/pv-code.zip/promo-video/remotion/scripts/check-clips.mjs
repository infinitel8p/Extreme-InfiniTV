// Verifies that every footage clip is long enough for the span the timeline reads from it.
// Run from the remotion folder: npm run check:clips (needs ffprobe on PATH).
import { execFileSync } from "node:child_process";
import path from "node:path";
import { fileURLToPath } from "node:url";

const FPS = 30;
const CROSSFADE = 0.35;
const FOOTAGE_DIR = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..", "public", "footage");

const spans = [
  { clip: "splash", inPoint: 0.27, from: 0, to: 3.2 },
  { clip: "hub", inPoint: 0.9, from: 3.2, to: 8.0 },
  { clip: "livetv", inPoint: 2.0, from: 8.0, to: 11.4 + CROSSFADE },
  { clip: "epg", inPoint: 1.0, from: 11.4, to: 13.6 },
  { clip: "tv-home", inPoint: 0.5, from: 13.6, to: 17.4 + CROSSFADE },
  { clip: "tv-live", inPoint: 1.0, from: 17.4, to: 20.4 },
  { clip: "search", inPoint: 0.3, from: 20.4, to: 24.2 },
  { clip: "phone-hub", inPoint: 0, from: 24.2, to: 28.6 + CROSSFADE },
  { clip: "phone-livetv", inPoint: 0, from: 24.2, to: 28.6 + CROSSFADE },
];

let failed = false;
for (const span of spans) {
  const file = path.join(FOOTAGE_DIR, `${span.clip}.mp4`);
  const duration = Number(
    execFileSync("ffprobe", ["-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", file]).toString().trim(),
  );
  const onScreenFrames = Math.round((span.to - span.from) * FPS);
  const lastSourceTime = (Math.round(span.inPoint * FPS) + onScreenFrames - 1) / FPS;
  const margin = duration - lastSourceTime;
  const ok = margin > 0;
  if (!ok) failed = true;
  console.log(
    `${ok ? "ok  " : "FAIL"} ${span.clip.padEnd(13)} source ${duration.toFixed(3)}s, last frame read at ${lastSourceTime.toFixed(3)}s, margin ${margin.toFixed(3)}s`,
  );
}
process.exit(failed ? 1 : 0);
