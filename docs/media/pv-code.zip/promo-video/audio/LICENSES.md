# Audio licences for the Extreme InfiniTV promo video

Collected 2026-09-01. The music bed and the two third-party sound effects come from freesound.org, where each sound page states its licence explicitly (the licence text and the creativecommons.org URL were read from the sound page before download). Files were fetched from freesound's public HQ preview endpoint (`https://cdn.freesound.org/previews/<prefix>/<id>_<userid>-hq.mp3`), the same route the app used for its own `ui-launch.wav`. Originals (WAV/FLAC) require a freesound login; swap them in for a lossless master if wanted, the licence is identical.

Licence texts:

- **CC0 1.0 Universal** (freesound label "Creative Commons 0"): <https://creativecommons.org/publicdomain/zero/1.0/>. Public domain dedication. No attribution required (credit is still a courtesy).
- **CC BY 4.0** (freesound label "Attribution 4.0"): <https://creativecommons.org/licenses/by/4.0/>. Commercial use and modification allowed; the credit line given per file must appear in the video description or end card, plus a note if the track was edited (trimmed/faded).

Every file was validated with `ffprobe`; loudness via `ffmpeg -af ebur128`. Percussiveness and tempo figures below came from a numpy analysis over decoded PCM at collection time. Nothing was auditioned by ear before the pick.

Everything the final cut uses is CC0 or owned by the project. No attribution is legally required; the courtesy credit block at the end is optional.

---

## Music in use

### candidate-1.mp3 (this folder; mastered copy at `remotion/public/audio/music.wav`)

- **Title**: Unpretentious Reveal (no drums)
- **Author**: SondreDrakensson (Sondre Drakensson)
- **Source URL**: <https://freesound.org/people/SondreDrakensson/sounds/529381/>
- **Licence (exact)**: Creative Commons 0 (CC0 1.0 Universal), <https://creativecommons.org/publicdomain/zero/1.0/>
- **Attribution required**: none. Courtesy credit: `"Unpretentious Reveal (no drums)" by Sondre Drakensson (freesound.org), CC0`
- **Author's description**: "This is a minimalistic unpretentious promo track made with technology and vehicles in mind." Drum-less alternate of sound 529380.
- **File**: MP3 (HQ preview), 44.1 kHz stereo, 59.45 s, sha256 `860f61a21b78f5bae2f6ca7a16c5b941abee6a99c6ecbddd3228b493a7317c8c`. Original on freesound: WAV 320 kbps-equivalent, 0:59.416.
- **Measurements (source file)**: integrated -19.0 LUFS, LRA 4.2 LU, true peak -0.5 dBTP. Percussive onsets 1.7 % (very low). Energy rises gently (+0.9 dB first third to last third) and peaks around 45-50 s. Tempo autocorrelation strongest at ~129 BPM with a half-time reading of ~65 BPM.
- **Processing in this project**: `remotion/scripts/prepare-music.mjs` applies +1.7 dB gain and a lookahead limiter with a -1 dBTP ceiling and writes 24-bit PCM. `Soundtrack.tsx` starts playback at 14 s into the track (`musicStartSeconds`) so the swell lands on the end card, with a 0.5 s fade-in and a 1.5 s fade-out.
- **Why it was picked**: written as a promo/reveal bed for technology products, explicitly minimal, no drums, CC0, 59 s so a 30-40 s cut with a natural swell at ~45 s is easy.
- **Caveat**: if the video ever needs a light pulse, sound 529380 (same author, same CC0, URL pattern `529/529380_6628165-hq.mp3`) is the identical arrangement with drums (measured -16.1 LUFS, 3.6 % percussive, ~96 BPM).

## Music alternatives (evaluated, not shipped in this folder)

Fetch from the source URL if one of these is wanted; run `npm run prepare:music -- ../audio/<file>` afterwards and re-measure loudness.

### Overlook (uplifting ambient loop), rank 2

- **Author**: SondreDrakensson (Sondre Drakensson). **Source URL**: <https://freesound.org/people/SondreDrakensson/sounds/506495/>
- **Licence (exact)**: Creative Commons 0 (CC0 1.0 Universal), <https://creativecommons.org/publicdomain/zero/1.0/>. Attribution: none required. Author writes: "You don't need to credit me, but if you do, use the name Sondre Drakensson."
- 78.05 s, -16.8 LUFS, true peak -3.3 dBTP, ~117-120 BPM, seamless loop, flat energy (the edit has to supply the build). sha256 `5fd494a1c9d46fb6bdab080066b1c0e9d1751c4b7ae27bb240fa67220dfc9987`.

### Ambient, Pad Piano - Event Horizon, rank 3

- **Author**: Andrewkn. **Source URL**: <https://freesound.org/people/Andrewkn/sounds/827922/>
- **Licence (exact)**: Attribution 4.0 (CC BY 4.0), <https://creativecommons.org/licenses/by/4.0/>. **Attribution required**: yes. Use: `"Ambient, Pad Piano - Event Horizon" by Andrewkn, https://freesound.org/s/827922/, licensed under CC BY 4.0 (https://creativecommons.org/licenses/by/4.0/). Trimmed and level-adjusted.`
- 96.03 s, -25.7 LUFS (needs ~+8 dB), true peak -13.0 dBTP, beatless pads and piano, author states 90 BPM, no build. sha256 `07fafc19a559ffafdc0c6dbfc117b56ef61d0f8a8a36b8706de0330cbe84b063`.

### Ambient Documentary Build Up #02, rank 4

- **Author**: tyops. **Source URL**: <https://freesound.org/people/tyops/sounds/437317/>
- **Licence (exact)**: Attribution 4.0 (CC BY 4.0), <https://creativecommons.org/licenses/by/4.0/>. **Attribution required**: yes. Use: `"Ambient Documentary Build Up #02" by tyops, https://freesound.org/s/437317/, licensed under CC BY 4.0 (https://creativecommons.org/licenses/by/4.0/). Trimmed.`
- 110.04 s, -15.6 LUFS, LRA 18.1 LU, true peak -0.5 dBTP, ~72 BPM, real build with an orchestral string climax at 80-100 s (drifts from minimal toward epic). sha256 `baf2c02d91e7aedbe9d08230dd76e6c2485ceead56e69c909d4258524ca19728`.

### Evaluated and rejected (not downloaded)

- 746454 "Spark of Inspiration" (ViraMiller, CC BY 4.0): loud (-12.4 LUFS), bright, reads as stock corporate.
- 752342 "Ascension" (Twotrickpony, CC BY 4.0): flat celestial drone, sci-fi flavour.
- 560442 "Pad Background Music" (Migfus20, CC BY 4.0): author describes it as "sad, and a little uneasy/insecure".
- 384202 "Slow Cinematic Music" (DeVern, CC0): "semi epic", front-loaded energy, -11.9 LUFS.
- 831993 "DreamyAmbientSoundtrack" (Akkaittou, CC BY 4.0): nostalgic and "somehow painful" per the author.
- 529380 "Unpretentious Reveal" (with drums): see the candidate-1 caveat.

---

## Sound effects in use (`remotion/public/audio/sfx/`)

### Project UI sounds (ui-nav.wav, ui-select.wav)

Copied from the app's `public/sounds/`. 48 kHz mono 16-bit; ui-nav 0.06 s, ui-select 0.14 s. Provenance: NOT third-party recordings. They are synthesised procedurally by the repo's `src/scripts/make-ui-sounds.mjs` (additive sine partials with attack/decay envelopes; its header says: "Synthesizes ui-nav / ui-select / ui-confirm in public/sounds/ (ui-launch.wav is a recording, see the README there)"). Because they are generated by the project's own code they are covered by the repository licence, GPL-3.0-or-later (`LICENSE`, `package.json`), so the project owns them outright and can use them freely in its own video. sha256: nav `447a133e46c2581ea498127268755ea2573c4d5af388de4fb828762ccfc84adc`, select `dbdcf4fe6a1ae0c5d9fcbfa1b6768bed0ee41d0b84318760a34cd371d4fdc8bd`.

The app's other two sounds (`ui-confirm.wav`, generated the same way, and `ui-launch.wav`, "Chord Reverse 1-Fmin" by CAT-FOX_ALEX, <https://freesound.org/people/CAT-FOX_ALEX/sounds/863888/>, CC0 per `public/sounds/README.md`) are not used in the video and are not shipped here.

### whoosh-soft.mp3 (transition)

- **Title**: Whoosh stereo light (transition)
- **Author**: xkeril
- **Source URL**: <https://freesound.org/people/xkeril/sounds/701104/>
- **Licence (exact)**: Creative Commons 0 (CC0 1.0 Universal), <https://creativecommons.org/publicdomain/zero/1.0/>
- **Attribution required**: none. Courtesy credit: `"Whoosh stereo light (transition)" by xkeril (freesound.org), CC0`
- **Author's description**: "An air woosh perfect for transition from left to right, like youtube video. Light soft and natural whoosh. It was made with a pump and some reverb, recorded in real stereo with a zoom h5n."
- **File**: MP3 (HQ preview), 48 kHz stereo, 2.35 s, -16.6 LUFS, true peak -4.0 dBTP, energy peaks at ~1 s then decays. sha256 `791bf392615c81ef7b0fd1a92fa39b847241ae0f995669f22573763edbaef07b`. Original: 48 kHz WAV, 0:02.316.

### impact-low.mp3 (logo reveal)

- **Title**: Low impact.wav
- **Author**: AudioPapkin
- **Source URL**: <https://freesound.org/people/AudioPapkin/sounds/430978/>
- **Licence (exact)**: Creative Commons 0 (CC0 1.0 Universal), <https://creativecommons.org/publicdomain/zero/1.0/>
- **Attribution required**: none. Courtesy credit: `"Low impact" by AudioPapkin (freesound.org), CC0`
- **Author's description**: "Low impact, is perfect for cinematic uses, video games."
- **File**: MP3 (HQ preview), 44.1 kHz stereo, 5.25 s, -12.6 LUFS, true peak -0.3 dBTP, hit at ~0-2 s with a ~3 s low tail (spectral centroid ~240 Hz). sha256 `bcf27da9931daf7030a8a4954235e1cf91eaecd1a7da254b9e2b748aa3c55a39`. Original: 44.1 kHz WAV, 0:05.223. The mix pulls it down against the music bed for a soft boom.

---

## Credit block

Nothing in the current cut legally requires attribution. Courtesy lines (optional):

```
Music: "Unpretentious Reveal (no drums)" by Sondre Drakensson (freesound.org), CC0
SFX: "Whoosh stereo light" by xkeril, "Low impact" by AudioPapkin (freesound.org), CC0
```

Required only if one of the CC BY alternatives is swapped in:

```
Music: "Ambient, Pad Piano - Event Horizon" by Andrewkn, https://freesound.org/s/827922/, CC BY 4.0, https://creativecommons.org/licenses/by/4.0/ (trimmed)
Music: "Ambient Documentary Build Up #02" by tyops, https://freesound.org/s/437317/, CC BY 4.0, https://creativecommons.org/licenses/by/4.0/ (trimmed)
```

## Limitations

- Lossless originals: freesound gates the original WAV/FLAC downloads behind a login; only the public HQ preview MP3s were fetched. No attempt was made to bypass the login.
- Pixabay uses its own Content Licence (not CC), so it was not considered.
